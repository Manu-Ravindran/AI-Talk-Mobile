# AI Talk by e& — Android v0.2

Target device: Samsung Galaxy S26 Ultra (SM-S948B)

## What changed
- Rebranded to **AI Talk** with official e& header logo.
- Uses the previously created red AI Talk app icon as the Android launcher icon.
- White, e&-red UI with improved chat bubbles and cleaner status/model controls.
- Keyboard/IME inset handling so the composer stays visible while typing.
- Single-file attachment and on-device extraction for PDF, TXT, CSV, JSON and Markdown.
- Local file context is sent only to the on-device Qwen model.
- Noon agent handoff: opens Noon search from a natural-language request.
- Gmail agent handoff: drafts the email locally, then opens Gmail compose with the draft.
- AI Talk still declares no Android INTERNET permission; the model remains offline.

## Security design for agents
AI Talk does not store or read Noon passwords, Google credentials, card numbers, CVVs, or bank credentials. Noon and Gmail keep their own authenticated sessions. A future UI-automation layer should require explicit user approval before any checkout/payment action.

## Model
Recommended: `Qwen3-1.7B_dynamic_wi4b32_afp32.litertlm`

## Build
Use the GitHub Actions workflow supplied alongside this package.
