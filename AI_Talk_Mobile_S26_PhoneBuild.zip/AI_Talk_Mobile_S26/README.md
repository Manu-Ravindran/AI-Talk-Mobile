# AI Talk by e& — Android Phone Build v0.5.0

This is the phone-build source package used by the existing GitHub Actions `build-apk.yml` workflow.

## Core AI
- Qwen3 1.7B INT4 LiteRT-LM model imported once into private app storage.
- Local GPU first, CPU fallback.
- Chat/document analysis remains on-device.
- Internet is used only for explicit Gmail agent or Noon actions.

## Attachments
Tap **+** in Chat or Gmail agent. Supported formats:
- PDF (text PDFs)
- Excel `.xlsx`, including multiple worksheets
- Word `.docx`, including tables
- TXT / CSV / JSON / Markdown

Excel extraction keeps sheet names, cell references and values and converts common Excel date cells to readable ISO dates. Word extraction reads paragraphs and table text. Files can also be shared into AI Talk from Android's share sheet.

Current prototype limits: legacy `.xls`/`.doc` are not supported, scanned/image-only PDFs do not have OCR, and one file can be active at a time.

## Gmail agent
The Mail agent is now Gmail-based and uses the official Google Identity Services authorization client plus Gmail REST API. The local AI remains responsible for summarization and drafting.

Requested scopes:
- `https://www.googleapis.com/auth/gmail.readonly`
- `https://www.googleapis.com/auth/gmail.send`

Supported test flows:
- `show inbox`
- `priority inbox`
- `summarize inbox`
- `find AITALK-MAIL-TEST-042`
- `reply to AITALK-MAIL-TEST-042 and confirm the requested action`
- `send an email to name@example.com confirming the meeting tomorrow`

New-email and reply sending always shows an in-app confirmation first. No silent send is implemented. A new email can include the currently attached file up to 2.5 MB.

### Google Cloud setup required once
This APK is signed with the included AI Talk development keystore, so use the following Android OAuth client values in Google Cloud:

- Package name: `com.eand.aitalkmobile`
- SHA-1: `21:E6:42:E1:8D:26:36:6D:C5:C7:FE:DF:B2:ED:10:86:90:A8:55:4A`

In the Google Cloud project:
1. Enable **Gmail API**.
2. Configure the Google Auth consent/branding screen.
3. Keep the app in **Testing** while evaluating and add the Gmail account(s) you will use as test users.
4. Create an **Android OAuth client** using the package name and SHA-1 above.
5. Install the APK, open **Gmail agent**, and tap **Connect Gmail**.

No client secret or Microsoft/Outlook configuration is required in the app.

## WhatsApp direction
WhatsApp is not wired into v0.5. The recommended first implementation is a local, approval-gated handoff: AI Talk drafts a message on-device and opens the official WhatsApp app with the message ready for the user to send. Full automated incoming-message handling requires a WhatsApp Business Platform / Cloud API integration and therefore a Meta-hosted/cloud component rather than a fully offline phone-only architecture.

## Build
Use the existing repository workflow. Replace the repository file `AI_Talk_Mobile_S26_PhoneBuild.zip` with this package and commit to `main`; the workflow extracts the project and runs `gradle :app:assembleDebug`.

See `QA-BUILD-REPORT-v0.5.txt` for QA coverage and remaining live Gmail validation.
