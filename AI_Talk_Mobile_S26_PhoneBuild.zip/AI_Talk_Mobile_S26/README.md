# AI Talk Mobile — Galaxy S26 Ultra offline prototype

A native Android prototype designed specifically for Samsung Galaxy S26 Ultra (SM-S948B).

## Runtime privacy

- No INTERNET permission is declared in the Android manifest.
- The LLM runs locally through Google LiteRT-LM.
- The app imports a `.litertlm` model from the phone's Downloads/files area into private app storage.
- Normal chat does not require a server, API key, login, or cloud model.

## Recommended model

`Qwen3-1.7B_dynamic_wi4b32_afp32.litertlm`

Why this build: it is an INT4 LiteRT-LM artifact with a 4096-token context and is specifically GPU-optimized. The LiteRT community publishes measured Galaxy S26 GPU results for this model. It is Apache-2.0 licensed.

## First run on the phone

1. Install the APK.
2. Download the recommended `.litertlm` model to the phone.
3. Open **AI Talk Mobile**.
4. Tap **IMPORT MODEL** and select the downloaded model.
5. Wait for the ~1 GB file to copy into app-private storage.
6. Tap **LOAD AI**.
7. Once the status says **AI ready • GPU • fully offline**, turn off Wi-Fi/mobile data if desired and test chat.

## Architecture

- Android / Kotlin
- LiteRT-LM Android 0.17.0
- GPU first (`Backend.GPU()`), CPU fallback
- 4096 token engine context
- Streaming generation callback
- No AndroidX dependencies
- No INTERNET permission

## Building

This source includes a GitHub Actions workflow that builds a debug APK using JDK 21, Android SDK 36, Gradle 8.13, and AGP 8.13.2.

You can also import the project into a modern Android development environment that supports JDK 21 and Gradle/AGP versions in the project files.

## Current v0.1 scope

Included: offline chat, model import, GPU inference, CPU fallback, persistent local model, streaming response UI.

Planned next: local conversation persistence, offline document RAG, voice input/output, local embeddings, reasoning toggle, performance telemetry, and optional NPU backend after GPU QA.
