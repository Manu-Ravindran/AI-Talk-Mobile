package com.eand.aitalkmobile

import java.util.Locale

object MailAgentLogic {
    fun priorityScore(message: MailMessage): Int {
        var score = 0
        if (!message.isRead) score += 2
        if (message.importance.equals("high", true)) score += 4
        val text = (message.subject + " " + message.bodyPreview).lowercase(Locale.US)
        val urgent = listOf(
            "urgent" to 3,
            "critical" to 3,
            "escalation" to 3,
            "action required" to 1,
            "overdue" to 1,
            "deadline" to 1,
            "today" to 1,
            "tomorrow" to 1,
            "approval required" to 1,
            "blocked" to 1
        )
        for ((keyword, points) in urgent) if (text.contains(keyword)) score += points
        return score
    }

    fun priorityLabel(score: Int): String = when {
        score >= 7 -> "HIGH"
        score >= 3 -> "MEDIUM"
        else -> "NORMAL"
    }

    fun search(messages: List<MailMessage>, query: String, limit: Int = 10): List<MailMessage> {
        val q = query.trim().lowercase(Locale.US)
        if (q.isBlank()) return emptyList()
        return messages.filter { m ->
            listOf(m.subject, m.fromName, m.fromAddress, m.bodyPreview)
                .any { it.lowercase(Locale.US).contains(q) }
        }.take(limit)
    }

    fun format(message: MailMessage): String {
        val unread = if (message.isRead) "" else "UNREAD • "
        val high = if (message.importance.equals("high", true)) "HIGH • " else ""
        val preview = message.bodyPreview.replace(Regex("\\s+"), " ").trim().take(220)
        return "$unread$high${message.subject}\nFrom: ${message.fromName.ifBlank { message.fromAddress }}\n$preview"
    }

    fun toContext(messages: List<MailMessage>, maxChars: Int): String = buildString {
        messages.forEachIndexed { index, m ->
            append("EMAIL ${index + 1}\n")
            append("SUBJECT: ${m.subject}\n")
            append("FROM: ${m.fromName} <${m.fromAddress}>\n")
            append("RECEIVED: ${m.receivedDateTime}\n")
            append("IMPORTANCE: ${m.importance}\n")
            append("READ: ${m.isRead}\n")
            append("PREVIEW: ${m.bodyPreview.replace(Regex("\\s+"), " ").trim()}\n\n")
        }
    }.take(maxChars)
}
