package com.eand.aitalkmobile

import android.text.Html
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.nio.charset.StandardCharsets
import java.time.Instant
import java.util.Base64
import java.util.Locale

class GmailApiClient {

    data class MailAttachment(
        val name: String,
        val contentType: String,
        val bytes: ByteArray
    )

    fun profileLabel(accessToken: String): String {
        val json = authorizedJson(
            accessToken,
            "GET",
            "$GMAIL_API/users/me/profile"
        )
        return json.optString("emailAddress").ifBlank { "Gmail account" }
    }

    fun listMessages(accessToken: String, wanted: Int): List<MailMessage> {
        if (wanted <= 0) return emptyList()
        val result = ArrayList<MailMessage>(wanted)
        var pageToken: String? = null
        while (result.size < wanted) {
            val pageSize = minOf(100, wanted - result.size)
            val url = buildString {
                append("$GMAIL_API/users/me/messages?maxResults=").append(pageSize)
                append("&includeSpamTrash=false")
                if (!pageToken.isNullOrBlank()) append("&pageToken=").append(enc(pageToken!!))
            }
            val listJson = authorizedJson(accessToken, "GET", url)
            val arr = listJson.optJSONArray("messages") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val id = arr.optJSONObject(i)?.optString("id").orEmpty()
                if (id.isBlank()) continue
                result.add(getMessageMetadata(accessToken, id))
                if (result.size >= wanted) break
            }
            pageToken = listJson.optString("nextPageToken").takeIf { it.isNotBlank() }
            if (pageToken == null || arr.length() == 0) break
        }
        return result
    }

    fun searchMessages(accessToken: String, query: String, wanted: Int = 20): List<MailMessage> {
        val trimmed = query.trim()
        if (trimmed.isBlank()) return emptyList()
        val url = "$GMAIL_API/users/me/messages?maxResults=${minOf(wanted, 100)}&includeSpamTrash=false&q=${enc(trimmed)}"
        val listJson = authorizedJson(accessToken, "GET", url)
        val arr = listJson.optJSONArray("messages") ?: JSONArray()
        val result = ArrayList<MailMessage>()
        for (i in 0 until arr.length()) {
            val id = arr.optJSONObject(i)?.optString("id").orEmpty()
            if (id.isBlank()) continue
            result.add(getMessageMetadata(accessToken, id))
            if (result.size >= wanted) break
        }
        return result
    }

    fun getMessage(accessToken: String, messageId: String): MailMessage {
        require(messageId.isNotBlank()) { "Message ID is missing" }
        val url = "$GMAIL_API/users/me/messages/${encPath(messageId)}?format=full"
        val json = authorizedJson(accessToken, "GET", url)
        return messageFromJson(json, includeFullBody = true)
    }

    fun sendMail(
        accessToken: String,
        to: String,
        subject: String,
        body: String,
        attachment: MailAttachment? = null
    ) {
        val raw = MailMimeBuilder.build(
            to = to,
            subject = subject,
            body = body,
            attachmentName = attachment?.name,
            attachmentContentType = attachment?.contentType,
            attachmentBytes = attachment?.bytes
        )
        val payload = JSONObject().put("raw", MailMimeBuilder.toBase64Url(raw)).toString()
        authorizedRaw(accessToken, "POST", "$GMAIL_API/users/me/messages/send", payload, "application/json")
    }

    fun replyToMessage(accessToken: String, original: MailMessage, body: String) {
        require(original.id.isNotBlank()) { "Message ID is missing" }
        val threadId = original.threadId.ifBlank {
            val fetched = getMessage(accessToken, original.id)
            fetched.threadId
        }
        val details = if (original.internetMessageId.isBlank() || original.fromAddress.isBlank()) {
            getMessage(accessToken, original.id)
        } else original

        val replySubject = if (details.subject.startsWith("Re:", true)) details.subject else "Re: ${details.subject}"
        val raw = MailMimeBuilder.build(
            to = details.fromAddress,
            subject = replySubject,
            body = body,
            inReplyTo = details.internetMessageId.takeIf { it.isNotBlank() },
            references = details.internetMessageId.takeIf { it.isNotBlank() }
        )
        val payload = JSONObject()
            .put("raw", MailMimeBuilder.toBase64Url(raw))
            .apply { if (threadId.isNotBlank()) put("threadId", threadId) }
            .toString()
        authorizedRaw(accessToken, "POST", "$GMAIL_API/users/me/messages/send", payload, "application/json")
    }

    private fun getMessageMetadata(accessToken: String, messageId: String): MailMessage {
        val fields = "id,threadId,labelIds,internalDate,snippet,payload(headers)"
        val url = "$GMAIL_API/users/me/messages/${encPath(messageId)}?format=metadata" +
            "&metadataHeaders=Subject&metadataHeaders=From&metadataHeaders=Date&metadataHeaders=Message-ID" +
            "&fields=${enc(fields)}"
        val json = authorizedJson(accessToken, "GET", url)
        return messageFromJson(json, includeFullBody = false)
    }

    private fun messageFromJson(json: JSONObject, includeFullBody: Boolean): MailMessage {
        val payload = json.optJSONObject("payload") ?: JSONObject()
        val headers = headersMap(payload.optJSONArray("headers"))
        val from = parseFrom(headers["from"].orEmpty())
        val labels = json.optJSONArray("labelIds")?.let { array ->
            buildSet {
                for (i in 0 until array.length()) add(array.optString(i))
            }
        } ?: emptySet()

        val internalMs = json.optString("internalDate").toLongOrNull()
        val received = headers["date"].orEmpty().ifBlank {
            internalMs?.let { Instant.ofEpochMilli(it).toString() }.orEmpty()
        }
        val snippet = json.optString("snippet")
        val body = if (includeFullBody) extractBestBody(payload).ifBlank { snippet } else snippet

        return MailMessage(
            id = json.optString("id"),
            subject = headers["subject"].orEmpty().ifBlank { "(no subject)" },
            fromName = from.first,
            fromAddress = from.second,
            receivedDateTime = received,
            isRead = !labels.contains("UNREAD"),
            importance = if (labels.contains("IMPORTANT")) "high" else "normal",
            bodyPreview = body.replace(Regex("\\s+"), " ").trim().take(if (includeFullBody) 12_000 else 1_500),
            threadId = json.optString("threadId"),
            internetMessageId = headers["message-id"].orEmpty()
        )
    }

    private fun headersMap(headers: JSONArray?): Map<String, String> {
        if (headers == null) return emptyMap()
        val result = linkedMapOf<String, String>()
        for (i in 0 until headers.length()) {
            val h = headers.optJSONObject(i) ?: continue
            val name = h.optString("name").lowercase(Locale.US)
            val value = h.optString("value")
            if (name.isNotBlank()) result[name] = value
        }
        return result
    }

    private fun parseFrom(value: String): Pair<String, String> {
        val trimmed = value.trim()
        val match = Regex("^(.*)<([^<>]+)>$").find(trimmed)
        return if (match != null) {
            val name = match.groupValues[1].trim().trim('"')
            name to match.groupValues[2].trim()
        } else {
            "" to trimmed.trim('"')
        }
    }

    private fun extractBestBody(payload: JSONObject): String {
        val plain = ArrayList<String>()
        val html = ArrayList<String>()

        fun walk(part: JSONObject) {
            val mime = part.optString("mimeType").lowercase(Locale.US)
            val bodyData = part.optJSONObject("body")?.optString("data").orEmpty()
            if (bodyData.isNotBlank()) {
                val decoded = try {
                    String(Base64.getUrlDecoder().decode(padBase64(bodyData)), StandardCharsets.UTF_8)
                } catch (_: Throwable) {
                    ""
                }
                when {
                    mime == "text/plain" && decoded.isNotBlank() -> plain.add(decoded)
                    mime == "text/html" && decoded.isNotBlank() -> html.add(decoded)
                }
            }
            val parts = part.optJSONArray("parts") ?: return
            for (i in 0 until parts.length()) {
                parts.optJSONObject(i)?.let { walk(it) }
            }
        }

        walk(payload)
        if (plain.isNotEmpty()) return plain.joinToString("\n\n").trim()
        if (html.isNotEmpty()) {
            return html.joinToString("\n\n") { Html.fromHtml(it, Html.FROM_HTML_MODE_LEGACY).toString() }.trim()
        }
        return ""
    }

    private fun padBase64(value: String): String {
        val rem = value.length % 4
        return if (rem == 0) value else value + "=".repeat(4 - rem)
    }

    private fun authorizedJson(accessToken: String, method: String, url: String): JSONObject {
        val response = requestRaw(accessToken, method, url, null, null)
        ensureSuccess(response)
        return JSONObject(response.body.ifBlank { "{}" })
    }

    private fun authorizedRaw(accessToken: String, method: String, url: String, body: String?, contentType: String?) {
        val response = requestRaw(accessToken, method, url, body, contentType)
        ensureSuccess(response)
    }

    private data class HttpResult(val code: Int, val body: String)

    private fun requestRaw(
        accessToken: String,
        method: String,
        url: String,
        body: String?,
        contentType: String?
    ): HttpResult {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 20_000
            readTimeout = 30_000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Authorization", "Bearer $accessToken")
            if (!contentType.isNullOrBlank()) setRequestProperty("Content-Type", contentType)
            if (body != null) doOutput = true
        }
        try {
            if (body != null) {
                connection.outputStream.use { it.write(body.toByteArray(StandardCharsets.UTF_8)) }
            }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader(StandardCharsets.UTF_8)?.use { it.readText() }.orEmpty()
            return HttpResult(code, text)
        } finally {
            connection.disconnect()
        }
    }

    private fun ensureSuccess(response: HttpResult) {
        if (response.code in 200..299) return
        val detail = try {
            JSONObject(response.body).optJSONObject("error")?.optString("message").orEmpty()
        } catch (_: Throwable) {
            ""
        }
        val suffix = detail.ifBlank { response.body.take(350) }
        if (response.code == 401) {
            throw IllegalStateException("Gmail authorization expired. Connect Gmail again.")
        }
        if (response.code == 403) {
            throw IllegalStateException("Gmail access was denied. Check that the Gmail API is enabled and the requested Gmail scopes are allowed for this test account. ${suffix.take(180)}")
        }
        throw IllegalStateException("Gmail API error ${response.code}: ${suffix.ifBlank { "Request failed" }}")
    }

    private fun enc(value: String): String = URLEncoder.encode(value, StandardCharsets.UTF_8.toString())
    private fun encPath(value: String): String = enc(value).replace("+", "%20")

    companion object {
        private const val GMAIL_API = "https://gmail.googleapis.com/gmail/v1"
    }
}
