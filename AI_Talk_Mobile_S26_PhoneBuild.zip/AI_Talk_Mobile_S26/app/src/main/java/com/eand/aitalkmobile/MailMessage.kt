package com.eand.aitalkmobile

data class MailMessage(
    val id: String,
    val subject: String,
    val fromName: String,
    val fromAddress: String,
    val receivedDateTime: String,
    val isRead: Boolean,
    val importance: String,
    val bodyPreview: String,
    val threadId: String = "",
    val internetMessageId: String = ""
)
