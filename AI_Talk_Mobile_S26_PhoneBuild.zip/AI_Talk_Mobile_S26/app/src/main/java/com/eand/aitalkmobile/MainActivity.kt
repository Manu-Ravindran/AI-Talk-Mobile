package com.eand.aitalkmobile

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.LogSeverity
import com.google.ai.edge.litertlm.Message
import com.google.ai.edge.litertlm.MessageCallback
import com.google.ai.edge.litertlm.SamplerConfig
import com.google.ai.edge.litertlm.ThinkingConfig
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private val ioExecutor = Executors.newSingleThreadExecutor()

    private lateinit var root: LinearLayout
    private lateinit var messages: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var status: TextView
    private lateinit var modelButton: Button
    private lateinit var loadButton: Button
    private lateinit var prompt: EditText
    private lateinit var sendButton: Button

    @Volatile private var engine: Engine? = null
    @Volatile private var conversation: Conversation? = null
    @Volatile private var generating = false
    private var activeAssistantBubble: TextView? = null

    private val modelDir by lazy { File(filesDir, "models").apply { mkdirs() } }
    private val localModel by lazy { File(modelDir, "model.litertlm") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Engine.setNativeMinLogSeverity(LogSeverity.ERROR)
        buildUi()
        refreshModelState()
    }

    private fun buildUi() {
        window.statusBarColor = Color.rgb(15, 16, 18)
        window.navigationBarColor = Color.rgb(15, 16, 18)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(12))
            setBackgroundColor(Color.rgb(15, 16, 18))
        }

        val title = TextView(this).apply {
            text = "AI Talk Mobile"
            textSize = 25f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        root.addView(title)

        val sub = TextView(this).apply {
            text = "On-device AI • Galaxy S26 Ultra • no cloud"
            textSize = 13f
            setTextColor(Color.rgb(170, 175, 184))
            setPadding(0, dp(3), 0, dp(12))
        }
        root.addView(sub)

        status = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.rgb(224, 74, 74))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.rgb(31, 33, 37))
        }
        root.addView(status, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(10)
        })

        val modelRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        modelButton = Button(this).apply {
            text = "IMPORT MODEL"
            setOnClickListener { chooseModel() }
        }
        modelRow.addView(modelButton, LinearLayout.LayoutParams(0, -2, 1f).apply {
            rightMargin = dp(5)
        })

        loadButton = Button(this).apply {
            text = "LOAD AI"
            isEnabled = false
            setOnClickListener { initializeLocalModel() }
        }
        modelRow.addView(loadButton, LinearLayout.LayoutParams(0, -2, 1f).apply {
            leftMargin = dp(5)
        })
        root.addView(modelRow)

        scroll = ScrollView(this).apply {
            isFillViewport = true
        }
        messages = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(12), 0, dp(12))
        }
        scroll.addView(messages, ScrollView.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
        }

        prompt = EditText(this).apply {
            hint = "Ask anything…"
            setHintTextColor(Color.rgb(135, 140, 148))
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(31, 33, 37))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            minLines = 1
            maxLines = 5
            isEnabled = false
        }
        inputRow.addView(prompt, LinearLayout.LayoutParams(0, -2, 1f).apply {
            rightMargin = dp(8)
        })

        sendButton = Button(this).apply {
            text = "SEND"
            isEnabled = false
            setOnClickListener { sendPrompt() }
        }
        inputRow.addView(sendButton, LinearLayout.LayoutParams(-2, -2))
        root.addView(inputRow)

        setContentView(root)

        addSystemMessage(
            "First setup: download Qwen3 1.7B INT4 (.litertlm) to your phone, tap IMPORT MODEL, then tap LOAD AI. " +
                "After that, the assistant works without internet."
        )
    }

    private fun chooseModel() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/octet-stream"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/octet-stream", "application/*", "*/*"))
        }
        startActivityForResult(intent, REQUEST_MODEL)
    }

    @Deprecated("Deprecated in Android SDK but intentionally kept dependency-free for this compact prototype")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_MODEL && resultCode == RESULT_OK) {
            data?.data?.let { importModel(it) }
        }
    }

    private fun importModel(uri: Uri) {
        modelButton.isEnabled = false
        loadButton.isEnabled = false
        status.text = "Importing model to private app storage…"
        status.setTextColor(Color.rgb(255, 190, 80))

        ioExecutor.execute {
            try {
                val size = querySize(uri)
                val temp = File(modelDir, "model.importing")
                contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "Cannot open selected model" }
                    FileOutputStream(temp).use { output ->
                        val buffer = ByteArray(4 * 1024 * 1024)
                        var copied = 0L
                        var lastPct = -1
                        while (true) {
                            val n = input.read(buffer)
                            if (n <= 0) break
                            output.write(buffer, 0, n)
                            copied += n
                            if (size > 0) {
                                val pct = ((copied * 100) / size).toInt()
                                if (pct != lastPct && pct % 2 == 0) {
                                    lastPct = pct
                                    runOnUiThread { status.text = "Importing model… $pct%" }
                                }
                            }
                        }
                    }
                }
                if (localModel.exists()) localModel.delete()
                check(temp.renameTo(localModel)) { "Could not finalize model import" }

                runOnUiThread {
                    status.text = "Model imported • ${formatBytes(localModel.length())} • ready to load"
                    status.setTextColor(Color.rgb(89, 214, 128))
                    modelButton.isEnabled = true
                    loadButton.isEnabled = true
                    Toast.makeText(this, "Model imported successfully", Toast.LENGTH_SHORT).show()
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    status.text = "Import failed: ${t.message ?: t.javaClass.simpleName}"
                    status.setTextColor(Color.rgb(224, 74, 74))
                    modelButton.isEnabled = true
                    refreshModelState()
                }
            }
        }
    }

    private fun initializeLocalModel() {
        if (!localModel.exists()) {
            Toast.makeText(this, "Import a .litertlm model first", Toast.LENGTH_SHORT).show()
            return
        }

        modelButton.isEnabled = false
        loadButton.isEnabled = false
        prompt.isEnabled = false
        sendButton.isEnabled = false
        status.text = "Loading Qwen on GPU… first load can take several seconds"
        status.setTextColor(Color.rgb(255, 190, 80))

        ioExecutor.execute {
            closeModel()
            var loadedEngine: Engine? = null
            var backend = "GPU"
            try {
                loadedEngine = Engine(
                    EngineConfig(
                        modelPath = localModel.absolutePath,
                        backend = Backend.GPU(),
                        maxNumTokens = 4096,
                        cacheDir = cacheDir.absolutePath
                    )
                )
                loadedEngine.initialize()
            } catch (gpuError: Throwable) {
                try { loadedEngine?.close() } catch (_: Throwable) {}
                backend = "CPU fallback"
                runOnUiThread { status.text = "GPU unavailable; trying CPU fallback…" }
                loadedEngine = Engine(
                    EngineConfig(
                        modelPath = localModel.absolutePath,
                        backend = Backend.CPU(threadCount = 6),
                        maxNumTokens = 4096,
                        cacheDir = cacheDir.absolutePath
                    )
                )
                loadedEngine.initialize()
            }

            try {
                val newConversation = loadedEngine.createConversation(
                    ConversationConfig(
                        systemInstruction = Contents.of(
                            "You are AI Talk Mobile, a capable private assistant running completely on-device. " +
                                "Answer accurately and directly. If uncertain, say so. Keep normal answers concise unless the user asks for detail."
                        ),
                        samplerConfig = SamplerConfig(
                            topK = 40,
                            topP = 0.90,
                            temperature = 0.65
                        ),
                        maxOutputToken = 1024,
                        thinkingConfig = ThinkingConfig(enableThinking = false)
                    )
                )
                engine = loadedEngine
                conversation = newConversation

                runOnUiThread {
                    status.text = "AI ready • $backend • fully offline"
                    status.setTextColor(Color.rgb(89, 214, 128))
                    modelButton.isEnabled = true
                    loadButton.isEnabled = true
                    prompt.isEnabled = true
                    sendButton.isEnabled = true
                    addSystemMessage("Model loaded on $backend. You can now switch off Wi‑Fi/mobile data and continue chatting.")
                }
            } catch (t: Throwable) {
                try { loadedEngine.close() } catch (_: Throwable) {}
                runOnUiThread {
                    status.text = "Model load failed: ${t.message ?: t.javaClass.simpleName}"
                    status.setTextColor(Color.rgb(224, 74, 74))
                    modelButton.isEnabled = true
                    loadButton.isEnabled = true
                }
            }
        }
    }

    private fun sendPrompt() {
        if (generating) return
        val text = prompt.text.toString().trim()
        if (text.isEmpty()) return
        val conv = conversation ?: return

        prompt.setText("")
        hideKeyboard()
        addUserMessage(text)
        activeAssistantBubble = addBubble("", false)
        generating = true
        sendButton.isEnabled = false
        prompt.isEnabled = false
        status.text = "Thinking locally…"
        status.setTextColor(Color.rgb(130, 180, 255))

        val answer = StringBuilder()
        try {
            conv.sendMessageAsync(
                text,
                object : MessageCallback {
                    override fun onMessage(message: Message) {
                        val chunk = message.toString()
                        if (chunk.isNotEmpty()) {
                            answer.append(chunk)
                            runOnUiThread {
                                activeAssistantBubble?.text = answer.toString()
                                scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
                            }
                        }
                    }

                    override fun onDone() {
                        runOnUiThread {
                            generating = false
                            sendButton.isEnabled = true
                            prompt.isEnabled = true
                            status.text = "AI ready • fully offline"
                            status.setTextColor(Color.rgb(89, 214, 128))
                            prompt.requestFocus()
                        }
                    }

                    override fun onError(throwable: Throwable) {
                        runOnUiThread {
                            generating = false
                            sendButton.isEnabled = true
                            prompt.isEnabled = true
                            activeAssistantBubble?.text = "Error: ${throwable.message ?: throwable.javaClass.simpleName}"
                            status.text = "Generation error"
                            status.setTextColor(Color.rgb(224, 74, 74))
                        }
                    }
                },
                maxOutputToken = 1024,
                thinkingConfig = ThinkingConfig(enableThinking = false)
            )
        } catch (t: Throwable) {
            generating = false
            sendButton.isEnabled = true
            prompt.isEnabled = true
            activeAssistantBubble?.text = "Error: ${t.message ?: t.javaClass.simpleName}"
        }
    }

    private fun addUserMessage(text: String) {
        addBubble(text, true)
    }

    private fun addSystemMessage(text: String) {
        val tv = TextView(this).apply {
            this.text = text
            textSize = 12.5f
            setTextColor(Color.rgb(170, 175, 184))
            setPadding(dp(4), dp(7), dp(4), dp(7))
        }
        messages.addView(tv, LinearLayout.LayoutParams(-1, -2))
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun addBubble(text: String, fromUser: Boolean): TextView {
        val wrapper = LinearLayout(this).apply {
            gravity = if (fromUser) Gravity.END else Gravity.START
            setPadding(0, dp(5), 0, dp(5))
        }
        val tv = TextView(this).apply {
            this.text = text
            textSize = 15.5f
            setTextColor(Color.WHITE)
            setPadding(dp(14), dp(11), dp(14), dp(11))
            setBackgroundColor(
                if (fromUser) Color.rgb(176, 31, 42)
                else Color.rgb(35, 38, 43)
            )
            maxWidth = (resources.displayMetrics.widthPixels * 0.84).toInt()
        }
        wrapper.addView(tv)
        messages.addView(wrapper, LinearLayout.LayoutParams(-1, -2))
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        return tv
    }

    private fun refreshModelState() {
        if (localModel.exists()) {
            status.text = "Local model found • ${formatBytes(localModel.length())} • tap LOAD AI"
            status.setTextColor(Color.rgb(89, 214, 128))
            loadButton.isEnabled = true
        } else {
            status.text = "No local model yet • import a .litertlm file"
            status.setTextColor(Color.rgb(224, 74, 74))
            loadButton.isEnabled = false
        }
    }

    private fun querySize(uri: Uri): Long {
        return try {
            contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getLong(0) else -1L
            } ?: -1L
        } catch (_: Throwable) {
            -1L
        }
    }

    private fun formatBytes(bytes: Long): String {
        val mb = bytes / (1024.0 * 1024.0)
        return if (mb >= 1024) String.format(Locale.US, "%.2f GB", mb / 1024.0)
        else String.format(Locale.US, "%.0f MB", mb)
    }

    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)
            ?.hideSoftInputFromWindow(prompt.windowToken, 0)
    }

    private fun closeModel() {
        try { conversation?.close() } catch (_: Throwable) {}
        conversation = null
        try { engine?.close() } catch (_: Throwable) {}
        engine = null
    }

    override fun onDestroy() {
        closeModel()
        ioExecutor.shutdownNow()
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    companion object {
        private const val REQUEST_MODEL = 9001
    }
}
