package com.eand.aitalkmobile

import android.accounts.Account
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.IntentSender
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView
import android.widget.Toast
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.LogSeverity
import com.google.ai.edge.litertlm.Message
import com.google.ai.edge.litertlm.MessageCallback
import com.google.ai.edge.litertlm.SamplerConfig
import com.google.ai.edge.litertlm.ThinkingConfig
import com.google.android.gms.auth.GoogleAuthException
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.UserRecoverableAuthException
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.Scope
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.concurrent.Executors
import java.util.regex.Pattern
import kotlin.math.max

class MainActivity : Activity() {

    private enum class Mode { CHAT, NOON, MAIL }

    private data class AttachmentSnapshot(val uri: Uri, val name: String, val mime: String, val size: Long)

    private val ioExecutor = Executors.newSingleThreadExecutor()
    private val mailExecutor = Executors.newSingleThreadExecutor()

    private lateinit var root: LinearLayout
    private lateinit var messages: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var status: TextView
    private lateinit var modelInfo: TextView
    private lateinit var modelButton: Button
    private lateinit var loadButton: Button
    private lateinit var prompt: EditText
    private lateinit var sendButton: Button
    private lateinit var attachButton: Button
    private lateinit var attachmentRow: LinearLayout
    private lateinit var attachmentName: TextView
    private lateinit var chatModeButton: Button
    private lateinit var noonModeButton: Button
    private lateinit var mailModeButton: Button

    @Volatile private var engine: Engine? = null
    @Volatile private var conversation: Conversation? = null
    @Volatile private var generating = false
    private var activeAssistantBubble: TextView? = null
    private var currentMode = Mode.CHAT
    private var loadedBackend = ""

    private val gmail by lazy { GmailApiClient() }
    @Volatile private var gmailAccessToken: String? = null
    private var gmailAccountLabel: String? = null
    private var pendingGmailAction: ((String) -> Unit)? = null
    @Volatile private var gmailAuthInProgress = false
    private var gmailFallbackAttempted = false
    private var gmailLegacyAccount: Account? = null
    private var cachedMailMessages: List<MailMessage> = emptyList()

    private var attachedFileName: String? = null
    private var attachedFileText: String? = null
    private var attachedFileUri: Uri? = null
    private var attachedFileMime: String? = null
    private var attachedFileSize: Long = -1L

    private val modelDir by lazy { File(filesDir, "models").apply { mkdirs() } }
    private val localModel by lazy { File(modelDir, "model.litertlm") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Engine.setNativeMinLogSeverity(LogSeverity.ERROR)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        buildUi()
        applyKeyboardInsets()
        refreshModelState()
        handleIncomingShare(intent)
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setBackgroundColor(Color.WHITE)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(10))
        }

        val logo = ImageView(this).apply {
            setImageResource(R.drawable.eand_logo)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            contentDescription = "e&"
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(48), dp(48)).apply {
            rightMargin = dp(10)
        })

        val titleStack = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleStack.addView(TextView(this).apply {
            text = "AI Talk"
            textSize = 27f
            setTextColor(BLACK)
            setTypeface(typeface, Typeface.BOLD)
            includeFontPadding = false
        })
        titleStack.addView(TextView(this).apply {
            text = "by e&  •  Private on-device AI"
            textSize = 12.5f
            setTextColor(MUTED)
            setPadding(0, dp(2), 0, 0)
        })
        header.addView(titleStack, LinearLayout.LayoutParams(0, -2, 1f))

        val offlineBadge = TextView(this).apply {
            text = "OFFLINE AI"
            textSize = 10.5f
            setTextColor(GREEN_DARK)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(7), dp(10), dp(7))
            background = roundedBg(GREEN_LIGHT, dp(20).toFloat())
        }
        header.addView(offlineBadge)
        root.addView(header)

        val modelCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), dp(12), dp(13), dp(12))
            background = roundedStrokeBg(Color.rgb(250, 250, 251), BORDER, dp(16).toFloat())
        }
        modelInfo = TextView(this).apply {
            text = "Qwen3 1.7B INT4"
            textSize = 13.5f
            setTextColor(BLACK)
            setTypeface(typeface, Typeface.BOLD)
        }
        modelCard.addView(modelInfo)

        status = TextView(this).apply {
            textSize = 12.2f
            setTextColor(MUTED)
            setPadding(0, dp(4), 0, dp(10))
        }
        modelCard.addView(status)

        val modelRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        modelButton = smallButton("Import model", outlined = true).apply {
            setOnClickListener { chooseModel() }
        }
        modelRow.addView(modelButton, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
            rightMargin = dp(5)
        })
        loadButton = smallButton("Load AI", outlined = false).apply {
            isEnabled = false
            setOnClickListener { initializeLocalModel() }
        }
        modelRow.addView(loadButton, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
            leftMargin = dp(5)
        })
        modelCard.addView(modelRow)
        root.addView(modelCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        val modeScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
        }
        val modeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        chatModeButton = modeButton("Chat") { setMode(Mode.CHAT) }
        noonModeButton = modeButton("Noon agent") { setMode(Mode.NOON) }
        mailModeButton = modeButton("Gmail agent") { setMode(Mode.MAIL) }
        modeRow.addView(chatModeButton)
        modeRow.addView(noonModeButton, LinearLayout.LayoutParams(-2, dp(38)).apply { leftMargin = dp(7) })
        modeRow.addView(mailModeButton, LinearLayout.LayoutParams(-2, dp(38)).apply { leftMargin = dp(7) })
        modeScroll.addView(modeRow)
        root.addView(modeScroll, LinearLayout.LayoutParams(-1, dp(44)).apply { bottomMargin = dp(3) })
        refreshModeButtons()

        scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setBackgroundColor(Color.WHITE)
        }
        messages = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(7), 0, dp(10))
        }
        scroll.addView(messages, android.widget.FrameLayout.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        attachmentRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
            setPadding(dp(10), dp(8), dp(8), dp(8))
            background = roundedStrokeBg(Color.rgb(255, 247, 248), EAND_RED, dp(12).toFloat())
        }
        attachmentName = TextView(this).apply {
            textSize = 12.5f
            setTextColor(BLACK)
            maxLines = 1
        }
        attachmentRow.addView(attachmentName, LinearLayout.LayoutParams(0, -2, 1f))
        val clearFile = Button(this).apply {
            text = "×"
            textSize = 20f
            isAllCaps = false
            setTextColor(EAND_RED)
            background = transparentBg()
            setPadding(dp(8), 0, dp(8), 0)
            minWidth = 0
            minimumWidth = 0
            setOnClickListener { clearAttachment() }
        }
        attachmentRow.addView(clearFile, LinearLayout.LayoutParams(dp(38), dp(34)))
        root.addView(attachmentRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })

        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
            setPadding(dp(7), dp(7), dp(7), dp(7))
            background = roundedStrokeBg(Color.WHITE, BORDER, dp(18).toFloat())
            elevation = dp(3).toFloat()
        }

        attachButton = Button(this).apply {
            text = "+"
            textSize = 22f
            setTextColor(EAND_RED)
            isAllCaps = false
            background = roundedBg(Color.rgb(255, 244, 245), dp(14).toFloat())
            minWidth = 0
            minimumWidth = 0
            setPadding(0, 0, 0, 0)
            setOnClickListener { chooseAttachment() }
        }
        composer.addView(attachButton, LinearLayout.LayoutParams(dp(44), dp(44)).apply { rightMargin = dp(7) })

        prompt = EditText(this).apply {
            hint = "Message AI Talk…"
            setHintTextColor(Color.rgb(145, 148, 154))
            setTextColor(BLACK)
            textSize = 15.5f
            background = transparentBg()
            setPadding(dp(6), dp(8), dp(6), dp(8))
            minLines = 1
            maxLines = 5
            isEnabled = true
            isFocusable = true
            isFocusableInTouchMode = true
            inputType = InputType.TYPE_CLASS_TEXT or
                InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            gravity = Gravity.CENTER_VERTICAL
            setOnClickListener {
                requestFocus()
                showKeyboard()
            }
        }
        composer.addView(prompt, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(7) })

        sendButton = Button(this).apply {
            text = "Send"
            textSize = 13.5f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = roundedBg(EAND_RED, dp(14).toFloat())
            minWidth = 0
            minimumWidth = 0
            setPadding(dp(13), 0, dp(13), 0)
            isEnabled = false
            setOnClickListener { sendCurrentRequest() }
        }
        composer.addView(sendButton, LinearLayout.LayoutParams(-2, dp(44)))
        root.addView(composer, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(5)
            bottomMargin = dp(2)
        })

        setContentView(root)

        addWelcomeMessage()
    }


    private fun handleIncomingShare(incoming: Intent?) {
        if (incoming?.action != Intent.ACTION_SEND) return
        currentMode = Mode.CHAT
        refreshModeButtons()

        val stream = if (android.os.Build.VERSION.SDK_INT >= 33) {
            incoming.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            @Suppress("DEPRECATION") incoming.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        }
        if (stream != null) {
            addSystemMessage("File received from another app. Processing it locally…")
            importAttachment(stream)
            return
        }

        val shared = incoming.getStringExtra(Intent.EXTRA_TEXT)?.trim().orEmpty()
        if (shared.isBlank()) return
        prompt.setText(shared)
        addSystemMessage("Text received from another app. Load AI if needed, then send to analyze it locally.")
    }

    private fun applyKeyboardInsets() {
        root.setOnApplyWindowInsetsListener { _, insets ->
            val bars = insets.getInsets(WindowInsets.Type.systemBars())
            val ime = insets.getInsets(WindowInsets.Type.ime())
            root.setPadding(
                dp(16) + bars.left,
                dp(10) + bars.top,
                dp(16) + bars.right,
                dp(8) + max(bars.bottom, ime.bottom)
            )
            insets
        }
        root.requestApplyInsets()
    }

    private fun addWelcomeMessage() {
        addAssistantMessage(
            "Hi — I’m AI Talk by e&. I run the language model on your phone. " +
                "You can chat, attach PDF, Excel or Word files for local analysis, or use the Gmail agent for inbox analysis and approval-gated email actions."
        )
    }

    private fun setMode(mode: Mode) {
        if (generating) return
        currentMode = mode
        refreshModeButtons()
        val aiReady = conversation != null
        when (mode) {
            Mode.CHAT -> {
                prompt.hint = "Message AI Talk…"
                attachButton.isEnabled = true
                prompt.isEnabled = true
                sendButton.isEnabled = true
                status.text = if (aiReady) "AI ready • $loadedBackend • fully offline" else status.text
            }
            Mode.NOON -> {
                prompt.hint = "What should I find on Noon?"
                attachButton.isEnabled = false
                prompt.isEnabled = true
                sendButton.isEnabled = true
                clearAttachment()
                addSystemMessage("Noon agent uses the Noon app or web app for search and checkout. AI Talk does not store your Noon password or card details.")
            }
            Mode.MAIL -> {
                prompt.hint = "Ask Gmail about inbox, draft an email, or reply…"
                attachButton.isEnabled = true
                prompt.isEnabled = true
                sendButton.isEnabled = true
                if (!gmailAccessToken.isNullOrBlank()) {
                    addSystemMessage("Gmail agent is connected${gmailAccountLabel?.let { " • $it" }.orEmpty()}. Inbox reading uses the Gmail API; AI analysis and drafting stay on-device.")
                } else {
                    addSystemMessage("Connect Gmail to read and analyze the inbox, draft replies, and send only after your approval. Google authorization is requested only when you use the Gmail agent.")
                    addActionButton("Connect Gmail") { authorizeGmail() }
                }
            }
        }
        prompt.requestFocus()
        showKeyboard()
    }

    private fun refreshModeButtons() {
        styleModeButton(chatModeButton, currentMode == Mode.CHAT)
        styleModeButton(noonModeButton, currentMode == Mode.NOON)
        styleModeButton(mailModeButton, currentMode == Mode.MAIL)
    }

    private fun styleModeButton(button: Button, selected: Boolean) {
        button.setTextColor(if (selected) Color.WHITE else BLACK)
        button.background = if (selected) roundedBg(EAND_RED, dp(18).toFloat())
        else roundedStrokeBg(Color.WHITE, BORDER, dp(18).toFloat())
    }

    private fun modeButton(text: String, action: () -> Unit): Button {
        return Button(this).apply {
            this.text = text
            textSize = 12.3f
            isAllCaps = false
            minWidth = 0
            minimumWidth = 0
            setPadding(dp(15), 0, dp(15), 0)
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(-2, dp(38))
        }
    }

    private fun chooseModel() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, REQUEST_MODEL)
    }

    private fun chooseAttachment() {
        if (currentMode == Mode.NOON) return
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(
                Intent.EXTRA_MIME_TYPES,
                arrayOf(
                    "application/pdf",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    "text/plain",
                    "text/csv",
                    "application/json",
                    "text/markdown"
                )
            )
        }
        startActivityForResult(intent, REQUEST_ATTACHMENT)
    }

    @Deprecated("Kept dependency-light for this Android build")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_GMAIL_AUTH) {
            // Google Play services can return diagnostic data even when the Activity result is not RESULT_OK.
            // Parse it first so a configuration error is not incorrectly shown as a user cancellation.
            if (data != null) {
                try {
                    val result = Identity.getAuthorizationClient(this)
                        .getAuthorizationResultFromIntent(data)
                    completeGmailAuthorization(result.accessToken)
                    return
                } catch (e: ApiException) {
                    if (resultCode == RESULT_OK) {
                        pendingGmailAction = null
                        gmailAuthInProgress = false
                        showMailError(IllegalStateException(gmailOauthErrorMessage(e.statusCode)))
                        return
                    }
                } catch (_: Throwable) {
                    // Fall through to the compatibility authorization path below.
                }
            }

            if (!gmailFallbackAttempted) {
                gmailFallbackAttempted = true
                gmailAuthInProgress = false
                status.text = "Trying Gmail compatibility sign-in…"
                status.setTextColor(AMBER)
                startGmailCompatibilitySignIn()
            } else {
                pendingGmailAction = null
                gmailAuthInProgress = false
                gmailFallbackAttempted = false
                status.text = "Gmail authorization not completed"
                status.setTextColor(EAND_RED)
                addSystemMessage(
                    "Google did not grant Gmail access. For this test build, Gmail API must be enabled, your Gmail address must be added as an OAuth test user, and the Android OAuth client must match this app package + signing SHA-1."
                )
            }
            return
        }

        if (requestCode == REQUEST_GMAIL_SIGN_IN) {
            if (resultCode != RESULT_OK || data == null) {
                pendingGmailAction = null
                gmailAuthInProgress = false
                gmailFallbackAttempted = false
                status.text = "Gmail sign-in cancelled"
                status.setTextColor(MUTED)
                return
            }
            try {
                val signedIn = GoogleSignIn.getSignedInAccountFromIntent(data)
                    .getResult(ApiException::class.java)
                val account = signedIn.account
                    ?: throw IllegalStateException("Google account was selected but Android did not return the account handle.")
                gmailLegacyAccount = account
                fetchCompatibilityGmailToken(account)
            } catch (e: ApiException) {
                pendingGmailAction = null
                gmailAuthInProgress = false
                gmailFallbackAttempted = false
                showMailError(IllegalStateException(gmailOauthErrorMessage(e.statusCode)))
            } catch (t: Throwable) {
                pendingGmailAction = null
                gmailAuthInProgress = false
                gmailFallbackAttempted = false
                showMailError(t)
            }
            return
        }

        if (requestCode == REQUEST_GMAIL_RECOVERY) {
            val account = gmailLegacyAccount
            if (resultCode == RESULT_OK && account != null) {
                fetchCompatibilityGmailToken(account)
            } else {
                pendingGmailAction = null
                gmailAuthInProgress = false
                gmailFallbackAttempted = false
                status.text = "Gmail permission not granted"
                status.setTextColor(MUTED)
            }
            return
        }


        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val takeFlags = data.flags and Intent.FLAG_GRANT_READ_URI_PERMISSION
            if (takeFlags != 0) contentResolver.takePersistableUriPermission(uri, takeFlags)
        } catch (_: Throwable) {
            // Some document providers grant only temporary access; immediate processing still works.
        }
        when (requestCode) {
            REQUEST_MODEL -> importModel(uri)
            REQUEST_ATTACHMENT -> importAttachment(uri)
        }
    }

    private fun importAttachment(uri: Uri) {
        val name = queryDisplayName(uri) ?: "attachment"
        status.text = "Reading $name locally…"
        status.setTextColor(AMBER)
        attachButton.isEnabled = false
        ioExecutor.execute {
            try {
                val extracted = FileTextExtractor.extract(this, uri, name)
                val clipped = if (extracted.length > FILE_CONTEXT_LIMIT) {
                    extracted.take(FILE_CONTEXT_LIMIT) + "\n\n[File content clipped for the mobile model context.]"
                } else extracted
                runOnUiThread {
                    attachedFileName = name
                    attachedFileText = clipped
                    attachedFileUri = uri
                    attachedFileMime = contentResolver.getType(uri) ?: mimeForName(name)
                    attachedFileSize = querySize(uri)
                    attachmentName.text = "Attached: $name"
                    attachmentRow.visibility = View.VISIBLE
                    attachButton.isEnabled = true
                    status.text = "File ready • ${formatBytes(querySize(uri).coerceAtLeast(0))} • processed on-device"
                    status.setTextColor(GREEN_DARK)
                    prompt.requestFocus()
                    showKeyboard()
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    attachButton.isEnabled = true
                    status.text = "Could not read file: ${t.message ?: t.javaClass.simpleName}"
                    status.setTextColor(EAND_RED)
                    Toast.makeText(this, "File could not be processed", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun clearAttachment() {
        attachedFileName = null
        attachedFileText = null
        attachedFileUri = null
        attachedFileMime = null
        attachedFileSize = -1L
        if (::attachmentRow.isInitialized) attachmentRow.visibility = View.GONE
    }

    private fun importModel(uri: Uri) {
        modelButton.isEnabled = false
        loadButton.isEnabled = false
        status.text = "Importing model to private app storage…"
        status.setTextColor(AMBER)

        ioExecutor.execute {
            try {
                val size = querySize(uri)
                val temp = File(modelDir, "model.importing")
                contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "Cannot open selected model" }
                    FileOutputStream(temp).use { output ->
                        val buffer = ByteArray(4 * 1024 * 1024)
                        var copied = 0L
                        var lastPct = -1
                        while (true) {
                            val n = input.read(buffer)
                            if (n <= 0) break
                            output.write(buffer, 0, n)
                            copied += n
                            if (size > 0) {
                                val pct = ((copied * 100) / size).toInt()
                                if (pct != lastPct && pct % 2 == 0) {
                                    lastPct = pct
                                    runOnUiThread { status.text = "Importing model… $pct%" }
                                }
                            }
                        }
                    }
                }
                if (localModel.exists()) localModel.delete()
                check(temp.renameTo(localModel)) { "Could not finalize model import" }

                runOnUiThread {
                    status.text = "Model imported • ${formatBytes(localModel.length())} • tap Load AI"
                    status.setTextColor(GREEN_DARK)
                    modelButton.isEnabled = true
                    loadButton.isEnabled = true
                    Toast.makeText(this, "Model imported", Toast.LENGTH_SHORT).show()
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    status.text = "Import failed: ${t.message ?: t.javaClass.simpleName}"
                    status.setTextColor(EAND_RED)
                    modelButton.isEnabled = true
                    refreshModelState()
                }
            }
        }
    }

    private fun initializeLocalModel() {
        if (!localModel.exists()) {
            Toast.makeText(this, "Import a .litertlm model first", Toast.LENGTH_SHORT).show()
            return
        }

        modelButton.isEnabled = false
        loadButton.isEnabled = false
        prompt.isEnabled = true
        sendButton.isEnabled = true
        status.text = "Loading Qwen on GPU…"
        status.setTextColor(AMBER)

        ioExecutor.execute {
            closeModel()
            var loadedEngine: Engine? = null
            var backend = "GPU"
            try {
                loadedEngine = Engine(
                    EngineConfig(
                        modelPath = localModel.absolutePath,
                        backend = Backend.GPU(),
                        maxNumTokens = 4096,
                        cacheDir = cacheDir.absolutePath
                    )
                )
                loadedEngine.initialize()
            } catch (_: Throwable) {
                try { loadedEngine?.close() } catch (_: Throwable) {}
                backend = "CPU fallback"
                runOnUiThread { status.text = "GPU unavailable • trying CPU…" }
                loadedEngine = Engine(
                    EngineConfig(
                        modelPath = localModel.absolutePath,
                        backend = Backend.CPU(threadCount = 6),
                        maxNumTokens = 4096,
                        cacheDir = cacheDir.absolutePath
                    )
                )
                loadedEngine.initialize()
            }

            try {
                val newConversation = loadedEngine.createConversation(
                    ConversationConfig(
                        systemInstruction = Contents.of(
                            "You are AI Talk by e&, a private on-device assistant. " +
                                "Be accurate, concise and practical. Never invent business numbers, prices, revenue, dates, quantities or claims. " +
                                "Preserve user-provided numbers exactly and label missing data as TBD. " +
                                "When a file is provided, answer strictly from the file and the user's instructions unless clearly marked as general knowledge."
                        ),
                        samplerConfig = SamplerConfig(topK = 40, topP = 0.90, temperature = 0.55),
                        maxOutputToken = 1000,
                        thinkingConfig = ThinkingConfig(enableThinking = false)
                    )
                )
                engine = loadedEngine
                conversation = newConversation
                loadedBackend = backend

                runOnUiThread {
                    status.text = "AI ready • $backend • fully offline"
                    status.setTextColor(GREEN_DARK)
                    modelButton.isEnabled = true
                    loadButton.isEnabled = true
                    prompt.isEnabled = true
                    sendButton.isEnabled = true
                    addSystemMessage("Qwen3 1.7B loaded on $backend. The model can now run with Wi‑Fi and mobile data switched off.")
                }
            } catch (t: Throwable) {
                try { loadedEngine.close() } catch (_: Throwable) {}
                runOnUiThread {
                    status.text = "Model load failed: ${t.message ?: t.javaClass.simpleName}"
                    status.setTextColor(EAND_RED)
                    modelButton.isEnabled = true
                    loadButton.isEnabled = true
                }
            }
        }
    }

    private fun sendCurrentRequest() {
        if (generating) return
        val text = prompt.text.toString().trim()
        if (text.isEmpty()) return

        when (currentMode) {
            Mode.CHAT -> sendChat(text)
            Mode.NOON -> handleNoonRequest(text)
            Mode.MAIL -> handleMailRequest(text)
        }
    }

    private fun sendChat(text: String) {
        val conv = conversation ?: run {
            Toast.makeText(this, "Load AI first", Toast.LENGTH_SHORT).show()
            return
        }
        val fileName = attachedFileName
        val fileText = attachedFileText
        val display = if (fileName != null) "$text\n\n📎 $fileName" else text
        var modelText = if (fileName != null && fileText != null) {
            "The user attached a file named '$fileName'.\n\n--- FILE CONTENT ---\n$fileText\n--- END FILE ---\n\nUser request: $text"
        } else text
        if (Regex("(?i)\\b(tubular|tabular|table)\\b").containsMatchIn(text)) {
            modelText += "\n\nFORMAT REQUIREMENT: Present the requested data as a compact Markdown table with a header row and separator row. Do not put the table inside a code block. Keep cells concise."
        }
        clearAttachment()
        runGeneration(conv, modelText, display)
    }

    private fun handleNoonRequest(text: String) {
        prompt.setText("")
        addUserMessage(text)
        addAssistantMessage("I can hand this request to Noon. I’ll open Noon with your request as the search. Login and payment remain inside Noon, and the final order stays under your control.")
        addActionButton("Search in Noon") {
            AlertDialog.Builder(this)
                .setTitle("Open Noon")
                .setMessage("Search Noon for:\n\n$text\n\nAI Talk will not read or store your Noon password or payment-card details.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Continue") { _, _ -> openNoon(text) }
                .show()
        }
    }

    private fun handleMailRequest(text: String) {
        val lower = text.lowercase(Locale.US)
        when {
            lower.contains("connect") && (lower.contains("gmail") || lower.contains("mail")) -> {
                prompt.setText("")
                addUserMessage(text)
                authorizeGmail()
            }
            lower.startsWith("find ") || lower.startsWith("search ") || lower.contains("find email") || lower.contains("search email") ->
                handleMailSearch(text)
            lower.contains("priority inbox") || lower.contains("urgent mail") || lower.contains("important mail") ->
                handlePriorityInbox(text)
            lower.contains("summarize inbox") || lower.contains("summarise inbox") || lower.contains("inbox summary") ->
                handleInboxSummary(text)
            lower == "show inbox" || lower == "inbox" || lower.contains("latest emails") || lower.contains("recent emails") ->
                handleShowInbox(text)
            lower.contains("reply") -> handleReplyRequest(text)
            findEmailAddress(text) != null -> draftNewMail(text)
            gmailAccessToken.isNullOrBlank() -> {
                prompt.setText("")
                addUserMessage(text)
                addAssistantMessage("Gmail is not connected yet. Tap Connect Gmail, choose your Google account, and approve inbox read + send access for this test build.")
                addActionButton("Connect Gmail") { authorizeGmail() }
            }
            else -> {
                prompt.setText("")
                addUserMessage(text)
                addAssistantMessage(
                    "Gmail agent is ready. Try ‘show inbox’, ‘priority inbox’, ‘summarize inbox’, " +
                        "‘find AITALK-MAIL-TEST-042’, ‘reply to AITALK-MAIL-TEST-042 …’, or include an email address to draft a new message."
                )
            }
        }
    }

    private fun authorizeGmail(action: ((String) -> Unit)? = null) {
        if (gmailAuthInProgress) {
            Toast.makeText(this, "Gmail authorization is already in progress", Toast.LENGTH_SHORT).show()
            return
        }
        gmailAuthInProgress = true
        gmailFallbackAttempted = false
        pendingGmailAction = action
        status.text = "Requesting Gmail access…"
        status.setTextColor(AMBER)

        val request = AuthorizationRequest.builder()
            .setRequestedScopes(
                listOf(
                    Scope(GMAIL_READONLY_SCOPE),
                    Scope(GMAIL_SEND_SCOPE)
                )
            )
            .build()

        Identity.getAuthorizationClient(this)
            .authorize(request)
            .addOnSuccessListener { result ->
                if (result.hasResolution()) {
                    val pendingIntent = result.pendingIntent
                    if (pendingIntent == null) {
                        gmailAuthInProgress = false
                        startGmailCompatibilitySignIn()
                        return@addOnSuccessListener
                    }
                    try {
                        startIntentSenderForResult(
                            pendingIntent.intentSender,
                            REQUEST_GMAIL_AUTH,
                            null,
                            0,
                            0,
                            0
                        )
                    } catch (e: IntentSender.SendIntentException) {
                        gmailAuthInProgress = false
                        startGmailCompatibilitySignIn()
                    }
                } else {
                    completeGmailAuthorization(result.accessToken)
                }
            }
            .addOnFailureListener { error ->
                gmailAuthInProgress = false
                if (!gmailFallbackAttempted) {
                    gmailFallbackAttempted = true
                    status.text = "Trying Gmail compatibility sign-in…"
                    startGmailCompatibilitySignIn()
                } else {
                    pendingGmailAction = null
                    gmailFallbackAttempted = false
                    showMailError(
                        IllegalStateException(
                            "Could not authorize Gmail. Gmail API must be enabled, your Gmail address must be listed as an OAuth test user, and the Android OAuth client must use package com.eand.aitalkmobile with SHA-1 21:E6:42:E1:8D:26:36:6D:C5:C7:FE:DF:B2:ED:10:86:90:A8:55:4A. ${error.message.orEmpty()}"
                        )
                    )
                }
            }
    }

    private fun startGmailCompatibilitySignIn() {
        if (gmailAuthInProgress) return
        gmailAuthInProgress = true
        status.text = "Choose your Google account…"
        status.setTextColor(AMBER)
        val options = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(
                Scope(GMAIL_READONLY_SCOPE),
                Scope(GMAIL_SEND_SCOPE)
            )
            .build()
        try {
            val client = GoogleSignIn.getClient(this, options)
            startActivityForResult(client.signInIntent, REQUEST_GMAIL_SIGN_IN)
        } catch (t: Throwable) {
            pendingGmailAction = null
            gmailAuthInProgress = false
            gmailFallbackAttempted = false
            showMailError(t)
        }
    }

    @Suppress("DEPRECATION")
    private fun fetchCompatibilityGmailToken(account: Account) {
        gmailAuthInProgress = true
        status.text = "Requesting Gmail permission…"
        status.setTextColor(AMBER)
        mailExecutor.execute {
            try {
                val token = GoogleAuthUtil.getToken(applicationContext, account, GMAIL_OAUTH_SCOPE)
                runOnUiThread { completeGmailAuthorization(token) }
            } catch (recoverable: UserRecoverableAuthException) {
                runOnUiThread {
                    try {
                        startActivityForResult(recoverable.intent, REQUEST_GMAIL_RECOVERY)
                    } catch (t: Throwable) {
                        pendingGmailAction = null
                        gmailAuthInProgress = false
                        gmailFallbackAttempted = false
                        showMailError(t)
                    }
                }
            } catch (auth: GoogleAuthException) {
                pendingGmailAction = null
                gmailAuthInProgress = false
                gmailFallbackAttempted = false
                showMailError(
                    IllegalStateException(
                        "Google rejected the Gmail authorization. Check OAuth test-user access and the Android OAuth client package/SHA-1. ${auth.message.orEmpty()}"
                    )
                )
            } catch (t: Throwable) {
                pendingGmailAction = null
                gmailAuthInProgress = false
                gmailFallbackAttempted = false
                showMailError(t)
            }
        }
    }

    private fun gmailOauthErrorMessage(statusCode: Int): String {
        return when (statusCode) {
            10 -> "Google OAuth configuration error (code 10). Create an Android OAuth client for package com.eand.aitalkmobile using SHA-1 21:E6:42:E1:8D:26:36:6D:C5:C7:FE:DF:B2:ED:10:86:90:A8:55:4A, enable Gmail API, and add this Gmail account as a test user."
            12501 -> "Google sign-in was cancelled before Gmail permission was granted."
            else -> "Google Gmail authorization failed (code $statusCode). Ensure Gmail API is enabled, the account is an OAuth test user, and the Android OAuth client package/SHA-1 match this APK."
        }
    }

    private fun completeGmailAuthorization(token: String?) {
        val accessToken = token?.trim().orEmpty()
        if (accessToken.isBlank()) {
            pendingGmailAction = null
            gmailAuthInProgress = false
            showMailError(IllegalStateException("Google did not return a Gmail access token."))
            return
        }
        gmailAccessToken = accessToken
        gmailFallbackAttempted = false
        val action = pendingGmailAction
        pendingGmailAction = null
        gmailAuthInProgress = false
        status.text = "Gmail authorized • checking account…"
        status.setTextColor(AMBER)
        mailExecutor.execute {
            try {
                val label = gmail.profileLabel(accessToken)
                gmailAccountLabel = label
                runOnUiThread {
                    status.text = "Gmail connected • $label"
                    status.setTextColor(GREEN_DARK)
                    addSystemMessage("Gmail connection complete. Inbox analysis stays local after messages are fetched, and every send/reply requires your approval.")
                    action?.invoke(accessToken)
                }
            } catch (t: Throwable) {
                gmailAccessToken = null
                gmailAccountLabel = null
                showMailError(t)
            }
        }
    }

    private fun withGmailAuthorization(action: (String) -> Unit) {
        val current = gmailAccessToken
        if (!current.isNullOrBlank()) {
            action(current)
        } else {
            authorizeGmail(action)
        }
    }

    private fun handleShowInbox(request: String) {
        prompt.setText("")
        addUserMessage(request)
        status.text = "Reading Gmail inbox…"
        status.setTextColor(AMBER)
        withGmailAuthorization { token ->
            mailExecutor.execute {
                try {
                    val items = gmail.listMessages(token, 30)
                    cachedMailMessages = items
                    val text = if (items.isEmpty()) "Inbox is empty." else items.take(15).mapIndexed { index, m ->
                        "${index + 1}. ${MailAgentLogic.format(m)}"
                    }.joinToString("\n\n")
                    runOnUiThread {
                        status.text = "Gmail ready • ${items.size} recent messages loaded"
                        status.setTextColor(GREEN_DARK)
                        addAssistantMessage(text)
                    }
                } catch (t: Throwable) {
                    if (isAuthExpired(t)) gmailAccessToken = null
                    showMailError(t)
                }
            }
        }
    }

    private fun handlePriorityInbox(request: String) {
        prompt.setText("")
        addUserMessage(request)
        status.text = "Scoring recent Gmail messages…"
        status.setTextColor(AMBER)
        withGmailAuthorization { token ->
            mailExecutor.execute {
                try {
                    val items = gmail.listMessages(token, 100)
                    cachedMailMessages = items
                    val ranked = items.map { it to MailAgentLogic.priorityScore(it) }
                        .sortedWith(compareByDescending<Pair<MailMessage, Int>> { it.second }
                            .thenByDescending { it.first.receivedDateTime })
                        .take(10)
                    val text = if (ranked.isEmpty()) "Inbox is empty." else ranked.mapIndexed { index, pair ->
                        val (m, score) = pair
                        "${index + 1}. ${MailAgentLogic.priorityLabel(score)} • ${MailAgentLogic.format(m)}"
                    }.joinToString("\n\n")
                    runOnUiThread {
                        status.text = "Priority Inbox ready • reviewed ${items.size} Gmail messages"
                        status.setTextColor(GREEN_DARK)
                        addAssistantMessage(text)
                    }
                } catch (t: Throwable) {
                    if (isAuthExpired(t)) gmailAccessToken = null
                    showMailError(t)
                }
            }
        }
    }

    private fun handleInboxSummary(request: String) {
        val conv = conversation ?: run {
            prompt.setText("")
            addUserMessage(request)
            addAssistantMessage("Load the local AI first for inbox summarization. Gmail can still be connected and ‘show inbox’ works without the AI model.")
            return
        }
        status.text = "Reading Gmail inbox…"
        status.setTextColor(AMBER)
        withGmailAuthorization { token ->
            mailExecutor.execute {
                try {
                    val items = gmail.listMessages(token, 40)
                    cachedMailMessages = items
                    val context = MailAgentLogic.toContext(items.take(20), FILE_CONTEXT_LIMIT)
                    runOnUiThread {
                        status.text = "Inbox loaded • summarizing locally…"
                        val modelPrompt =
                            "Summarize this Gmail inbox snapshot. Identify the highest-priority items, requested actions, deadlines only when explicitly present, and any blockers. " +
                                "Do not invent details. Use concise bullets.\n\n$context"
                        runGeneration(conv, modelPrompt, request)
                    }
                } catch (t: Throwable) {
                    if (isAuthExpired(t)) gmailAccessToken = null
                    showMailError(t)
                }
            }
        }
    }

    private fun handleMailSearch(request: String) {
        prompt.setText("")
        addUserMessage(request)
        status.text = "Searching Gmail…"
        status.setTextColor(AMBER)
        val reference = Regex("(?i)AITALK-MAIL-TEST-\\d{3}").find(request)?.value
        val query = reference ?: request
            .replace(Regex("(?i)^(find|search)\\s+"), "")
            .replace(Regex("(?i)\\b(email|mail|inbox|for)\\b"), " ")
            .trim()
        withGmailAuthorization { token ->
            mailExecutor.execute {
                try {
                    val serverQuery = if (reference != null) "\"$reference\"" else query
                    val hits = gmail.searchMessages(token, serverQuery, 15)
                    cachedMailMessages = (hits + cachedMailMessages).distinctBy { it.id }.take(100)
                    val text = if (hits.isEmpty()) "No recent Gmail messages matched ‘$query’." else hits.mapIndexed { index, m ->
                        "${index + 1}. ${MailAgentLogic.format(m)}"
                    }.joinToString("\n\n")
                    runOnUiThread {
                        status.text = "Gmail search complete"
                        status.setTextColor(GREEN_DARK)
                        addAssistantMessage(text)
                    }
                } catch (t: Throwable) {
                    if (isAuthExpired(t)) gmailAccessToken = null
                    showMailError(t)
                }
            }
        }
    }

    private fun handleReplyRequest(request: String) {
        val conv = conversation ?: run {
            Toast.makeText(this, "Load AI first", Toast.LENGTH_SHORT).show()
            return
        }
        prompt.setText("")
        addUserMessage(request)
        status.text = "Finding the Gmail message to reply to…"
        status.setTextColor(AMBER)
        val reference = Regex("(?i)AITALK-MAIL-TEST-\\d{3}").find(request)?.value
        val searchPhrase = reference ?: request
            .replace(Regex("(?i)^reply\\s+(to\\s+)?"), "")
            .substringBefore(" and ")
            .trim()

        withGmailAuthorization { token ->
            mailExecutor.execute {
                try {
                    val serverQuery = if (reference != null) "\"$reference\"" else searchPhrase
                    val hits = gmail.searchMessages(token, serverQuery, 10)
                    val target = hits.firstOrNull() ?: cachedMailMessages.firstOrNull { m ->
                        listOf(m.subject, m.fromName, m.fromAddress, m.bodyPreview)
                            .any { it.contains(searchPhrase, ignoreCase = true) }
                    }
                    if (target == null) {
                        runOnUiThread {
                            status.text = "No matching Gmail message found"
                            status.setTextColor(EAND_RED)
                            addAssistantMessage("I could not identify the email to reply to. Use its subject or test reference, for example ‘reply to AITALK-MAIL-TEST-042 …’.")
                        }
                        return@execute
                    }
                    val fullTarget = gmail.getMessage(token, target.id)
                    val modelPrompt =
                        "Draft a professional reply to the email below. Return only the reply body, no subject label and no commentary. " +
                            "Use only information in the source email and the user's instruction; do not invent facts.\n\n" +
                            "EMAIL CONTENT: ${fullTarget.bodyPreview}\n\nUSER INSTRUCTION: $request"
                    runOnUiThread {
                        status.text = "Email found • drafting locally…"
                        runGeneration(conv, modelPrompt, request) { replyBody ->
                            addActionButton("Send reply via Gmail") {
                                confirmAndSendReply(fullTarget, replyBody)
                            }
                        }
                    }
                } catch (t: Throwable) {
                    if (isAuthExpired(t)) gmailAccessToken = null
                    showMailError(t)
                }
            }
        }
    }

    private fun draftNewMail(request: String) {
        val conv = conversation ?: run {
            Toast.makeText(this, "Load AI first", Toast.LENGTH_SHORT).show()
            return
        }
        val recipient = findEmailAddress(request) ?: return
        val attachment = currentAttachmentSnapshot()
        val fileContext = if (attachedFileName != null && attachedFileText != null) {
            "\n\nThe user also attached '${attachedFileName}'. Use this content only if relevant to the requested draft:\n--- ATTACHMENT CONTENT ---\n${attachedFileText}\n--- END ATTACHMENT ---"
        } else ""
        val modelPrompt =
            "Draft the email requested below. Return exactly this format and nothing else:\n" +
                "SUBJECT: <short subject>\nBODY: <email body>\n\nRequest: $request$fileContext"
        val display = if (attachment != null) "$request\n\n📎 ${attachment.name}" else request
        runGeneration(conv, modelPrompt, display) { answer ->
            val draft = parseEmailDraft(answer)
            addActionButton("Send via Gmail") {
                confirmAndSendMail(recipient, draft.first, draft.second, attachment)
            }
        }
    }

    private fun confirmAndSendMail(
        recipient: String,
        subject: String,
        body: String,
        attachment: AttachmentSnapshot?
    ) {
        val attachmentLine = attachment?.let { "\nAttachment: ${it.name}" }.orEmpty()
        AlertDialog.Builder(this)
            .setTitle("Send email via Gmail?")
            .setMessage("To: $recipient\nSubject: $subject$attachmentLine\n\n$body")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Send") { _, _ ->
                status.text = "Sending through Gmail…"
                status.setTextColor(AMBER)
                withGmailAuthorization { token ->
                    mailExecutor.execute {
                        try {
                            val gmailAttachment = attachment?.let { snapshot ->
                                require(snapshot.size < 0 || snapshot.size <= MAIL_ATTACHMENT_LIMIT) {
                                    "Attachment is too large for this demo. Keep mail attachments under 2.5 MB."
                                }
                                GmailApiClient.MailAttachment(
                                    snapshot.name,
                                    snapshot.mime,
                                    readUriBytesLimited(snapshot.uri, MAIL_ATTACHMENT_LIMIT)
                                )
                            }
                            gmail.sendMail(token, recipient, subject, body, gmailAttachment)
                            runOnUiThread {
                                status.text = "Email sent via Gmail"
                                status.setTextColor(GREEN_DARK)
                                addSystemMessage("Email sent through Gmail after your approval.")
                                clearAttachment()
                            }
                        } catch (t: Throwable) {
                            if (isAuthExpired(t)) gmailAccessToken = null
                            showMailError(t)
                        }
                    }
                }
            }
            .show()
    }

    private fun confirmAndSendReply(message: MailMessage, body: String) {
        AlertDialog.Builder(this)
            .setTitle("Send reply via Gmail?")
            .setMessage("Reply to: ${message.fromName} <${message.fromAddress}>\nSubject: ${message.subject}\n\n$body")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Send reply") { _, _ ->
                status.text = "Sending reply through Gmail…"
                status.setTextColor(AMBER)
                withGmailAuthorization { token ->
                    mailExecutor.execute {
                        try {
                            gmail.replyToMessage(token, message, body)
                            runOnUiThread {
                                status.text = "Reply sent via Gmail"
                                status.setTextColor(GREEN_DARK)
                                addSystemMessage("Reply sent through Gmail after your approval.")
                            }
                        } catch (t: Throwable) {
                            if (isAuthExpired(t)) gmailAccessToken = null
                            showMailError(t)
                        }
                    }
                }
            }
            .show()
    }

    private fun isAuthExpired(t: Throwable): Boolean =
        t.message?.contains("authorization expired", ignoreCase = true) == true

    private fun currentAttachmentSnapshot(): AttachmentSnapshot? {
        val uri = attachedFileUri ?: return null
        val name = attachedFileName ?: "attachment"
        return AttachmentSnapshot(uri, name, attachedFileMime ?: mimeForName(name), attachedFileSize)
    }

    private fun readUriBytesLimited(uri: Uri, limit: Int): ByteArray {
        contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Could not open attachment" }
            val out = java.io.ByteArrayOutputStream()
            val buffer = ByteArray(8192)
            var total = 0
            while (true) {
                val n = input.read(buffer)
                if (n <= 0) break
                total += n
                require(total <= limit) { "Attachment is too large for this demo. Keep mail attachments under 2.5 MB." }
                out.write(buffer, 0, n)
            }
            return out.toByteArray()
        }
    }

    private fun showMailError(t: Throwable) {
        runOnUiThread {
            status.text = "Mail error: ${t.message ?: t.javaClass.simpleName}"
            status.setTextColor(EAND_RED)
            addSystemMessage("Mail agent error: ${t.message ?: t.javaClass.simpleName}")
        }
    }

    private fun mimeForName(name: String): String = when (name.substringAfterLast('.', "").lowercase(Locale.US)) {
        "pdf" -> "application/pdf"
        "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        "txt" -> "text/plain"
        "csv" -> "text/csv"
        "json" -> "application/json"
        "md" -> "text/markdown"
        else -> "application/octet-stream"
    }

    private fun runGeneration(
        conv: Conversation,
        modelText: String,
        displayText: String,
        onComplete: ((String) -> Unit)? = null
    ) {
        prompt.setText("")
        addUserMessage(displayText)
        activeAssistantBubble = addBubble("", false)
        generating = true
        sendButton.isEnabled = false
        prompt.isEnabled = false
        status.text = "Thinking locally…"
        status.setTextColor(Color.rgb(80, 110, 180))

        val answer = StringBuilder()
        try {
            conv.sendMessageAsync(
                modelText,
                object : MessageCallback {
                    override fun onMessage(message: Message) {
                        val chunk = message.toString()
                        if (chunk.isNotEmpty()) {
                            answer.append(chunk)
                            runOnUiThread {
                                activeAssistantBubble?.text = cleanMarkdown(answer.toString())
                                scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
                            }
                        }
                    }

                    override fun onDone() {
                        val finalText = cleanMarkdown(answer.toString()).trim()
                        runOnUiThread {
                            activeAssistantBubble?.let { renderStructuredAssistantBubble(it, finalText) }
                            generating = false
                            sendButton.isEnabled = true
                            prompt.isEnabled = true
                            status.text = "AI ready • $loadedBackend • fully offline"
                            status.setTextColor(GREEN_DARK)
                            prompt.requestFocus()
                            showKeyboard()
                            onComplete?.invoke(finalText)
                        }
                    }

                    override fun onError(throwable: Throwable) {
                        runOnUiThread {
                            generating = false
                            sendButton.isEnabled = true
                            prompt.isEnabled = true
                            activeAssistantBubble?.text = "Error: ${throwable.message ?: throwable.javaClass.simpleName}"
                            status.text = "Generation error"
                            status.setTextColor(EAND_RED)
                        }
                    }
                },
                maxOutputToken = 1000,
                thinkingConfig = ThinkingConfig(enableThinking = false)
            )
        } catch (t: Throwable) {
            generating = false
            sendButton.isEnabled = true
            prompt.isEnabled = true
            activeAssistantBubble?.text = "Error: ${t.message ?: t.javaClass.simpleName}"
        }
    }

    private fun openNoon(query: String) {
        try {
            val url = "https://www.noon.com/uae-en/search?q=${Uri.encode(query)}"
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (t: Throwable) {
            Toast.makeText(this, "Could not open Noon: ${t.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun findEmailAddress(text: String): String? {
        val matcher = EMAIL_PATTERN.matcher(text)
        return if (matcher.find()) matcher.group() else null
    }

    private fun parseEmailDraft(text: String): Pair<String, String> {
        val subjectMatch = Regex("(?im)^SUBJECT:\\s*(.+)$").find(text)
        val bodyMatch = Regex("(?is)BODY:\\s*(.*)$").find(text)
        val subject = subjectMatch?.groupValues?.getOrNull(1)?.trim().orEmpty().ifBlank { "AI Talk draft" }
        val body = bodyMatch?.groupValues?.getOrNull(1)?.trim().orEmpty().ifBlank {
            text.replace(Regex("(?im)^SUBJECT:.*$"), "").replace(Regex("(?im)^BODY:\\s*"), "").trim()
        }
        return subject to body
    }

    private fun cleanMarkdown(text: String): String {
        return text
            .replace("**", "")
            .replace(Regex("(?m)^#{1,6}\\s*"), "")
    }

    private data class ParsedMarkdownTable(
        val before: String,
        val headers: List<String>,
        val rows: List<List<String>>,
        val after: String
    )

    private fun parseMarkdownTable(text: String): ParsedMarkdownTable? {
        val lines = text.lines()
        for (i in 0 until lines.size - 1) {
            val header = lines[i].trim()
            val separator = lines[i + 1].trim()
            if (!header.startsWith("|") || header.count { it == '|' } < 3) continue
            if (!separator.startsWith("|") || !separator.matches(Regex("^[|:\\-\\s]+$"))) continue

            fun cells(line: String): List<String> = line.trim()
                .removePrefix("|")
                .removeSuffix("|")
                .split('|')
                .map { it.trim() }

            val headers = cells(header)
            if (headers.size < 2) continue
            val rows = mutableListOf<List<String>>()
            var j = i + 2
            while (j < lines.size) {
                val candidate = lines[j].trim()
                if (!candidate.startsWith("|") || candidate.count { it == '|' } < 2) break
                val row = cells(candidate)
                if (row.size < 2) break
                rows += if (row.size == headers.size) row else row.take(headers.size) + List(maxOf(0, headers.size - row.size)) { "" }
                j++
            }
            if (rows.isEmpty()) continue
            return ParsedMarkdownTable(
                before = lines.take(i).joinToString("\n").trim(),
                headers = headers,
                rows = rows,
                after = lines.drop(j).joinToString("\n").trim()
            )
        }
        return null
    }

    private fun renderStructuredAssistantBubble(textView: TextView, text: String) {
        val parsed = parseMarkdownTable(text) ?: run {
            textView.text = text
            return
        }
        val wrapper = textView.parent as? LinearLayout ?: run {
            textView.text = text
            return
        }
        wrapper.removeAllViews()

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(11), dp(12), dp(11))
            background = roundedStrokeBg(Color.rgb(246, 247, 249), Color.rgb(232, 234, 238), dp(17).toFloat())
        }
        val maxCardWidth = (resources.displayMetrics.widthPixels * 0.94).toInt()

        fun addParagraph(value: String) {
            if (value.isBlank()) return
            card.addView(TextView(this).apply {
                this.text = value
                textSize = 14.5f
                setTextColor(BLACK)
                setLineSpacing(dp(1).toFloat(), 1.03f)
                setPadding(dp(2), dp(2), dp(2), dp(8))
            }, LinearLayout.LayoutParams(-1, -2))
        }

        addParagraph(parsed.before)

        val horizontal = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }
        val table = TableLayout(this).apply {
            isShrinkAllColumns = false
            isStretchAllColumns = false
        }

        fun addRow(values: List<String>, header: Boolean) {
            val row = TableRow(this)
            values.forEach { value ->
                row.addView(TextView(this).apply {
                    text = value
                    textSize = if (header) 13.2f else 12.8f
                    setTextColor(BLACK)
                    if (header) setTypeface(typeface, Typeface.BOLD)
                    setPadding(dp(9), dp(8), dp(9), dp(8))
                    minWidth = dp(if (values.size >= 5) 118 else 145)
                    maxWidth = dp(210)
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        setColor(if (header) Color.rgb(235, 237, 240) else Color.WHITE)
                        setStroke(dp(1), Color.rgb(215, 218, 223))
                    }
                })
            }
            table.addView(row)
        }

        addRow(parsed.headers, true)
        parsed.rows.forEach { addRow(it, false) }
        horizontal.addView(table, android.widget.FrameLayout.LayoutParams(-2, -2))
        card.addView(horizontal, LinearLayout.LayoutParams(maxCardWidth - dp(24), -2))
        if (parsed.after.isNotBlank()) {
            card.addView(TextView(this).apply {
                this.text = parsed.after
                textSize = 14.5f
                setTextColor(BLACK)
                setPadding(dp(2), dp(9), dp(2), dp(2))
            }, LinearLayout.LayoutParams(-1, -2))
        }
        wrapper.addView(card, LinearLayout.LayoutParams(maxCardWidth, -2))
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun addUserMessage(text: String) {
        addBubble(text, true)
    }

    private fun addAssistantMessage(text: String) {
        addBubble(text, false)
    }

    private fun addSystemMessage(text: String) {
        val tv = TextView(this).apply {
            this.text = text
            textSize = 11.8f
            setTextColor(MUTED)
            setPadding(dp(6), dp(7), dp(6), dp(7))
        }
        messages.addView(tv, LinearLayout.LayoutParams(-1, -2))
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun addBubble(text: String, fromUser: Boolean): TextView {
        val wrapper = LinearLayout(this).apply {
            gravity = if (fromUser) Gravity.END else Gravity.START
            setPadding(0, dp(5), 0, dp(5))
        }
        val tv = TextView(this).apply {
            this.text = text
            textSize = 15.2f
            setTextColor(if (fromUser) Color.WHITE else BLACK)
            setPadding(dp(14), dp(11), dp(14), dp(11))
            background = if (fromUser) roundedBg(EAND_RED, dp(17).toFloat())
            else roundedStrokeBg(Color.rgb(246, 247, 249), Color.rgb(232, 234, 238), dp(17).toFloat())
            maxWidth = (resources.displayMetrics.widthPixels * 0.84).toInt()
            setLineSpacing(dp(1).toFloat(), 1.03f)
        }
        wrapper.addView(tv)
        messages.addView(wrapper, LinearLayout.LayoutParams(-1, -2))
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        return tv
    }

    private fun addActionButton(label: String, action: () -> Unit) {
        val wrapper = LinearLayout(this).apply {
            gravity = Gravity.START
            setPadding(0, 0, 0, dp(7))
        }
        val button = smallButton(label, outlined = true).apply {
            setTextColor(EAND_RED)
            setOnClickListener { action() }
        }
        wrapper.addView(button, LinearLayout.LayoutParams(-2, dp(42)))
        messages.addView(wrapper)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun refreshModelState() {
        if (!generating) {
            prompt.isEnabled = true
            sendButton.isEnabled = true
        }
        if (localModel.exists()) {
            status.text = "Local model found • ${formatBytes(localModel.length())} • tap Load AI"
            status.setTextColor(GREEN_DARK)
            loadButton.isEnabled = true
        } else {
            status.text = "Import Qwen3 1.7B .litertlm once, then it stays on this phone"
            status.setTextColor(MUTED)
            loadButton.isEnabled = false
        }
    }

    private fun querySize(uri: Uri): Long {
        return try {
            contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getLong(0) else -1L
            } ?: -1L
        } catch (_: Throwable) {
            -1L
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "local"
        val mb = bytes / (1024.0 * 1024.0)
        return if (mb >= 1024) String.format(Locale.US, "%.2f GB", mb / 1024.0)
        else String.format(Locale.US, "%.0f MB", mb)
    }

    private fun showKeyboard() {
        prompt.postDelayed({
            (getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)
                ?.showSoftInput(prompt, InputMethodManager.SHOW_IMPLICIT)
        }, 120)
    }

    private fun smallButton(label: String, outlined: Boolean): Button {
        return Button(this).apply {
            text = label
            textSize = 12.8f
            isAllCaps = false
            minWidth = 0
            minimumWidth = 0
            setPadding(dp(14), 0, dp(14), 0)
            setTextColor(if (outlined) BLACK else Color.WHITE)
            background = if (outlined) roundedStrokeBg(Color.WHITE, BORDER, dp(12).toFloat())
            else roundedBg(EAND_RED, dp(12).toFloat())
        }
    }

    private fun roundedBg(color: Int, radius: Float): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(color)
            cornerRadius = radius
        }
    }

    private fun roundedStrokeBg(color: Int, stroke: Int, radius: Float): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(color)
            setStroke(dp(1), stroke)
            cornerRadius = radius
        }
    }

    private fun transparentBg(): GradientDrawable = roundedBg(Color.TRANSPARENT, 0f)

    private fun closeModel() {
        try { conversation?.close() } catch (_: Throwable) {}
        conversation = null
        try { engine?.close() } catch (_: Throwable) {}
        engine = null
    }

    override fun onDestroy() {
        closeModel()
        ioExecutor.shutdownNow()
        mailExecutor.shutdownNow()
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    companion object {
        private const val REQUEST_MODEL = 9001
        private const val REQUEST_ATTACHMENT = 9002
        private const val REQUEST_GMAIL_AUTH = 9003
        private const val REQUEST_GMAIL_SIGN_IN = 9004
        private const val REQUEST_GMAIL_RECOVERY = 9005
        private const val GMAIL_READONLY_SCOPE = "https://www.googleapis.com/auth/gmail.readonly"
        private const val GMAIL_SEND_SCOPE = "https://www.googleapis.com/auth/gmail.send"
        private const val GMAIL_OAUTH_SCOPE = "oauth2:$GMAIL_READONLY_SCOPE $GMAIL_SEND_SCOPE"
        private const val FILE_CONTEXT_LIMIT = 11_000
        private const val MAIL_ATTACHMENT_LIMIT = 2_500_000

        private val EAND_RED = Color.rgb(220, 0, 28)
        private val BLACK = Color.rgb(27, 28, 31)
        private val MUTED = Color.rgb(105, 108, 115)
        private val BORDER = Color.rgb(224, 226, 230)
        private val GREEN_LIGHT = Color.rgb(232, 249, 239)
        private val GREEN_DARK = Color.rgb(26, 128, 72)
        private val AMBER = Color.rgb(177, 111, 0)
        private val EMAIL_PATTERN: Pattern = Pattern.compile("[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}", Pattern.CASE_INSENSITIVE)
    }
}
