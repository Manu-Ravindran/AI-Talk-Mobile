package com.eand.aitalkmobile

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.LogSeverity
import com.google.ai.edge.litertlm.Message
import com.google.ai.edge.litertlm.MessageCallback
import com.google.ai.edge.litertlm.SamplerConfig
import com.google.ai.edge.litertlm.ThinkingConfig
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.concurrent.Executors
import java.util.regex.Pattern
import kotlin.math.max

class MainActivity : Activity() {

    private enum class Mode { CHAT, NOON, GMAIL }

    private val ioExecutor = Executors.newSingleThreadExecutor()

    private lateinit var root: LinearLayout
    private lateinit var messages: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var status: TextView
    private lateinit var modelInfo: TextView
    private lateinit var modelButton: Button
    private lateinit var loadButton: Button
    private lateinit var prompt: EditText
    private lateinit var sendButton: Button
    private lateinit var attachButton: Button
    private lateinit var attachmentRow: LinearLayout
    private lateinit var attachmentName: TextView
    private lateinit var chatModeButton: Button
    private lateinit var noonModeButton: Button
    private lateinit var gmailModeButton: Button

    @Volatile private var engine: Engine? = null
    @Volatile private var conversation: Conversation? = null
    @Volatile private var generating = false
    private var activeAssistantBubble: TextView? = null
    private var currentMode = Mode.CHAT
    private var loadedBackend = ""

    private var attachedFileName: String? = null
    private var attachedFileText: String? = null

    private val modelDir by lazy { File(filesDir, "models").apply { mkdirs() } }
    private val localModel by lazy { File(modelDir, "model.litertlm") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Engine.setNativeMinLogSeverity(LogSeverity.ERROR)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        buildUi()
        applyKeyboardInsets()
        refreshModelState()
        handleIncomingShare(intent)
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setBackgroundColor(Color.WHITE)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(10))
        }

        val logo = ImageView(this).apply {
            setImageResource(R.drawable.eand_logo)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            contentDescription = "e&"
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(48), dp(48)).apply {
            rightMargin = dp(10)
        })

        val titleStack = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleStack.addView(TextView(this).apply {
            text = "AI Talk"
            textSize = 27f
            setTextColor(BLACK)
            setTypeface(typeface, Typeface.BOLD)
            includeFontPadding = false
        })
        titleStack.addView(TextView(this).apply {
            text = "by e&  •  Private on-device AI"
            textSize = 12.5f
            setTextColor(MUTED)
            setPadding(0, dp(2), 0, 0)
        })
        header.addView(titleStack, LinearLayout.LayoutParams(0, -2, 1f))

        val offlineBadge = TextView(this).apply {
            text = "OFFLINE AI"
            textSize = 10.5f
            setTextColor(GREEN_DARK)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(7), dp(10), dp(7))
            background = roundedBg(GREEN_LIGHT, dp(20).toFloat())
        }
        header.addView(offlineBadge)
        root.addView(header)

        val modelCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), dp(12), dp(13), dp(12))
            background = roundedStrokeBg(Color.rgb(250, 250, 251), BORDER, dp(16).toFloat())
        }
        modelInfo = TextView(this).apply {
            text = "Qwen3 1.7B INT4"
            textSize = 13.5f
            setTextColor(BLACK)
            setTypeface(typeface, Typeface.BOLD)
        }
        modelCard.addView(modelInfo)

        status = TextView(this).apply {
            textSize = 12.2f
            setTextColor(MUTED)
            setPadding(0, dp(4), 0, dp(10))
        }
        modelCard.addView(status)

        val modelRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        modelButton = smallButton("Import model", outlined = true).apply {
            setOnClickListener { chooseModel() }
        }
        modelRow.addView(modelButton, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
            rightMargin = dp(5)
        })
        loadButton = smallButton("Load AI", outlined = false).apply {
            isEnabled = false
            setOnClickListener { initializeLocalModel() }
        }
        modelRow.addView(loadButton, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
            leftMargin = dp(5)
        })
        modelCard.addView(modelRow)
        root.addView(modelCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        val modeScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
        }
        val modeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        chatModeButton = modeButton("Chat") { setMode(Mode.CHAT) }
        noonModeButton = modeButton("Noon agent") { setMode(Mode.NOON) }
        gmailModeButton = modeButton("Gmail agent") { setMode(Mode.GMAIL) }
        modeRow.addView(chatModeButton)
        modeRow.addView(noonModeButton, LinearLayout.LayoutParams(-2, dp(38)).apply { leftMargin = dp(7) })
        modeRow.addView(gmailModeButton, LinearLayout.LayoutParams(-2, dp(38)).apply { leftMargin = dp(7) })
        modeScroll.addView(modeRow)
        root.addView(modeScroll, LinearLayout.LayoutParams(-1, dp(44)).apply { bottomMargin = dp(3) })
        refreshModeButtons()

        scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setBackgroundColor(Color.WHITE)
        }
        messages = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(7), 0, dp(10))
        }
        scroll.addView(messages, android.widget.FrameLayout.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        attachmentRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
            setPadding(dp(10), dp(8), dp(8), dp(8))
            background = roundedStrokeBg(Color.rgb(255, 247, 248), EAND_RED, dp(12).toFloat())
        }
        attachmentName = TextView(this).apply {
            textSize = 12.5f
            setTextColor(BLACK)
            maxLines = 1
        }
        attachmentRow.addView(attachmentName, LinearLayout.LayoutParams(0, -2, 1f))
        val clearFile = Button(this).apply {
            text = "×"
            textSize = 20f
            isAllCaps = false
            setTextColor(EAND_RED)
            background = transparentBg()
            setPadding(dp(8), 0, dp(8), 0)
            minWidth = 0
            minimumWidth = 0
            setOnClickListener { clearAttachment() }
        }
        attachmentRow.addView(clearFile, LinearLayout.LayoutParams(dp(38), dp(34)))
        root.addView(attachmentRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })

        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
            setPadding(dp(7), dp(7), dp(7), dp(7))
            background = roundedStrokeBg(Color.WHITE, BORDER, dp(18).toFloat())
            elevation = dp(3).toFloat()
        }

        attachButton = Button(this).apply {
            text = "+"
            textSize = 22f
            setTextColor(EAND_RED)
            isAllCaps = false
            background = roundedBg(Color.rgb(255, 244, 245), dp(14).toFloat())
            minWidth = 0
            minimumWidth = 0
            setPadding(0, 0, 0, 0)
            setOnClickListener { chooseAttachment() }
        }
        composer.addView(attachButton, LinearLayout.LayoutParams(dp(44), dp(44)).apply { rightMargin = dp(7) })

        prompt = EditText(this).apply {
            hint = "Message AI Talk…"
            setHintTextColor(Color.rgb(145, 148, 154))
            setTextColor(BLACK)
            textSize = 15.5f
            background = transparentBg()
            setPadding(dp(6), dp(8), dp(6), dp(8))
            minLines = 1
            maxLines = 5
            isEnabled = false
            gravity = Gravity.CENTER_VERTICAL
        }
        composer.addView(prompt, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(7) })

        sendButton = Button(this).apply {
            text = "Send"
            textSize = 13.5f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = roundedBg(EAND_RED, dp(14).toFloat())
            minWidth = 0
            minimumWidth = 0
            setPadding(dp(13), 0, dp(13), 0)
            isEnabled = false
            setOnClickListener { sendCurrentRequest() }
        }
        composer.addView(sendButton, LinearLayout.LayoutParams(-2, dp(44)))
        root.addView(composer, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(5)
            bottomMargin = dp(2)
        })

        setContentView(root)

        addWelcomeMessage()
    }


    private fun handleIncomingShare(incoming: Intent?) {
        if (incoming?.action != Intent.ACTION_SEND) return
        if (incoming.type?.startsWith("text/") != true) return
        val shared = incoming.getStringExtra(Intent.EXTRA_TEXT)?.trim().orEmpty()
        if (shared.isBlank()) return
        currentMode = Mode.CHAT
        refreshModeButtons()
        prompt.setText(shared)
        addSystemMessage("Text received from another app. Load AI if needed, then send to analyze it locally.")
    }

    private fun applyKeyboardInsets() {
        root.setOnApplyWindowInsetsListener { _, insets ->
            val bars = insets.getInsets(WindowInsets.Type.systemBars())
            val ime = insets.getInsets(WindowInsets.Type.ime())
            root.setPadding(
                dp(16) + bars.left,
                dp(10) + bars.top,
                dp(16) + bars.right,
                dp(8) + max(bars.bottom, ime.bottom)
            )
            insets
        }
        root.requestApplyInsets()
    }

    private fun addWelcomeMessage() {
        addAssistantMessage(
            "Hi — I’m AI Talk by e&. I run the language model on your phone. " +
                "You can chat, attach one file for analysis, or use the Noon and Gmail agent handoffs."
        )
    }

    private fun setMode(mode: Mode) {
        if (generating) return
        currentMode = mode
        refreshModeButtons()
        val aiReady = conversation != null
        when (mode) {
            Mode.CHAT -> {
                prompt.hint = "Message AI Talk…"
                attachButton.isEnabled = true
                prompt.isEnabled = aiReady
                sendButton.isEnabled = aiReady
                status.text = if (aiReady) "AI ready • $loadedBackend • fully offline" else status.text
            }
            Mode.NOON -> {
                prompt.hint = "What should I find on Noon?"
                attachButton.isEnabled = false
                prompt.isEnabled = true
                sendButton.isEnabled = true
                clearAttachment()
                addSystemMessage("Noon agent uses the Noon app or web app for search and checkout. AI Talk does not store your Noon password or card details.")
            }
            Mode.GMAIL -> {
                prompt.hint = "Describe the email you want to send…"
                attachButton.isEnabled = false
                prompt.isEnabled = aiReady
                sendButton.isEnabled = aiReady
                clearAttachment()
                addSystemMessage("Gmail agent drafts locally, then opens the Gmail compose screen. Your Google credentials stay inside Gmail.")
            }
        }
        prompt.requestFocus()
        showKeyboard()
    }

    private fun refreshModeButtons() {
        styleModeButton(chatModeButton, currentMode == Mode.CHAT)
        styleModeButton(noonModeButton, currentMode == Mode.NOON)
        styleModeButton(gmailModeButton, currentMode == Mode.GMAIL)
    }

    private fun styleModeButton(button: Button, selected: Boolean) {
        button.setTextColor(if (selected) Color.WHITE else BLACK)
        button.background = if (selected) roundedBg(EAND_RED, dp(18).toFloat())
        else roundedStrokeBg(Color.WHITE, BORDER, dp(18).toFloat())
    }

    private fun modeButton(text: String, action: () -> Unit): Button {
        return Button(this).apply {
            this.text = text
            textSize = 12.3f
            isAllCaps = false
            minWidth = 0
            minimumWidth = 0
            setPadding(dp(15), 0, dp(15), 0)
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(-2, dp(38))
        }
    }

    private fun chooseModel() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, REQUEST_MODEL)
    }

    private fun chooseAttachment() {
        if (currentMode != Mode.CHAT) return
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(
                Intent.EXTRA_MIME_TYPES,
                arrayOf(
                    "application/pdf",
                    "text/plain",
                    "text/csv",
                    "application/json",
                    "text/markdown"
                )
            )
        }
        startActivityForResult(intent, REQUEST_ATTACHMENT)
    }

    @Deprecated("Kept dependency-light for this Android build")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            REQUEST_MODEL -> importModel(uri)
            REQUEST_ATTACHMENT -> importAttachment(uri)
        }
    }

    private fun importAttachment(uri: Uri) {
        val name = queryDisplayName(uri) ?: "attachment"
        status.text = "Reading $name locally…"
        status.setTextColor(AMBER)
        attachButton.isEnabled = false
        ioExecutor.execute {
            try {
                val extracted = FileTextExtractor.extract(this, uri, name)
                val clipped = if (extracted.length > FILE_CONTEXT_LIMIT) {
                    extracted.take(FILE_CONTEXT_LIMIT) + "\n\n[File content clipped for the mobile model context.]"
                } else extracted
                runOnUiThread {
                    attachedFileName = name
                    attachedFileText = clipped
                    attachmentName.text = "Attached: $name"
                    attachmentRow.visibility = View.VISIBLE
                    attachButton.isEnabled = true
                    status.text = "File ready • ${formatBytes(querySize(uri).coerceAtLeast(0))} • processed on-device"
                    status.setTextColor(GREEN_DARK)
                    prompt.requestFocus()
                    showKeyboard()
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    attachButton.isEnabled = true
                    status.text = "Could not read file: ${t.message ?: t.javaClass.simpleName}"
                    status.setTextColor(EAND_RED)
                    Toast.makeText(this, "File could not be processed", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun clearAttachment() {
        attachedFileName = null
        attachedFileText = null
        if (::attachmentRow.isInitialized) attachmentRow.visibility = View.GONE
    }

    private fun importModel(uri: Uri) {
        modelButton.isEnabled = false
        loadButton.isEnabled = false
        status.text = "Importing model to private app storage…"
        status.setTextColor(AMBER)

        ioExecutor.execute {
            try {
                val size = querySize(uri)
                val temp = File(modelDir, "model.importing")
                contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "Cannot open selected model" }
                    FileOutputStream(temp).use { output ->
                        val buffer = ByteArray(4 * 1024 * 1024)
                        var copied = 0L
                        var lastPct = -1
                        while (true) {
                            val n = input.read(buffer)
                            if (n <= 0) break
                            output.write(buffer, 0, n)
                            copied += n
                            if (size > 0) {
                                val pct = ((copied * 100) / size).toInt()
                                if (pct != lastPct && pct % 2 == 0) {
                                    lastPct = pct
                                    runOnUiThread { status.text = "Importing model… $pct%" }
                                }
                            }
                        }
                    }
                }
                if (localModel.exists()) localModel.delete()
                check(temp.renameTo(localModel)) { "Could not finalize model import" }

                runOnUiThread {
                    status.text = "Model imported • ${formatBytes(localModel.length())} • tap Load AI"
                    status.setTextColor(GREEN_DARK)
                    modelButton.isEnabled = true
                    loadButton.isEnabled = true
                    Toast.makeText(this, "Model imported", Toast.LENGTH_SHORT).show()
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    status.text = "Import failed: ${t.message ?: t.javaClass.simpleName}"
                    status.setTextColor(EAND_RED)
                    modelButton.isEnabled = true
                    refreshModelState()
                }
            }
        }
    }

    private fun initializeLocalModel() {
        if (!localModel.exists()) {
            Toast.makeText(this, "Import a .litertlm model first", Toast.LENGTH_SHORT).show()
            return
        }

        modelButton.isEnabled = false
        loadButton.isEnabled = false
        prompt.isEnabled = false
        sendButton.isEnabled = false
        status.text = "Loading Qwen on GPU…"
        status.setTextColor(AMBER)

        ioExecutor.execute {
            closeModel()
            var loadedEngine: Engine? = null
            var backend = "GPU"
            try {
                loadedEngine = Engine(
                    EngineConfig(
                        modelPath = localModel.absolutePath,
                        backend = Backend.GPU(),
                        maxNumTokens = 4096,
                        cacheDir = cacheDir.absolutePath
                    )
                )
                loadedEngine.initialize()
            } catch (_: Throwable) {
                try { loadedEngine?.close() } catch (_: Throwable) {}
                backend = "CPU fallback"
                runOnUiThread { status.text = "GPU unavailable • trying CPU…" }
                loadedEngine = Engine(
                    EngineConfig(
                        modelPath = localModel.absolutePath,
                        backend = Backend.CPU(threadCount = 6),
                        maxNumTokens = 4096,
                        cacheDir = cacheDir.absolutePath
                    )
                )
                loadedEngine.initialize()
            }

            try {
                val newConversation = loadedEngine.createConversation(
                    ConversationConfig(
                        systemInstruction = Contents.of(
                            "You are AI Talk by e&, a private on-device assistant. " +
                                "Be accurate, concise and practical. Never invent business numbers, prices, revenue, dates, quantities or claims. " +
                                "Preserve user-provided numbers exactly and label missing data as TBD. " +
                                "When a file is provided, answer strictly from the file and the user's instructions unless clearly marked as general knowledge."
                        ),
                        samplerConfig = SamplerConfig(topK = 40, topP = 0.90, temperature = 0.55),
                        maxOutputToken = 1000,
                        thinkingConfig = ThinkingConfig(enableThinking = false)
                    )
                )
                engine = loadedEngine
                conversation = newConversation
                loadedBackend = backend

                runOnUiThread {
                    status.text = "AI ready • $backend • fully offline"
                    status.setTextColor(GREEN_DARK)
                    modelButton.isEnabled = true
                    loadButton.isEnabled = true
                    prompt.isEnabled = true
                    sendButton.isEnabled = true
                    addSystemMessage("Qwen3 1.7B loaded on $backend. The model can now run with Wi‑Fi and mobile data switched off.")
                }
            } catch (t: Throwable) {
                try { loadedEngine.close() } catch (_: Throwable) {}
                runOnUiThread {
                    status.text = "Model load failed: ${t.message ?: t.javaClass.simpleName}"
                    status.setTextColor(EAND_RED)
                    modelButton.isEnabled = true
                    loadButton.isEnabled = true
                }
            }
        }
    }

    private fun sendCurrentRequest() {
        if (generating) return
        val text = prompt.text.toString().trim()
        if (text.isEmpty()) return

        when (currentMode) {
            Mode.CHAT -> sendChat(text)
            Mode.NOON -> handleNoonRequest(text)
            Mode.GMAIL -> sendGmailDraft(text)
        }
    }

    private fun sendChat(text: String) {
        val conv = conversation ?: run {
            Toast.makeText(this, "Load AI first", Toast.LENGTH_SHORT).show()
            return
        }
        val fileName = attachedFileName
        val fileText = attachedFileText
        val display = if (fileName != null) "$text\n\n📎 $fileName" else text
        val modelText = if (fileName != null && fileText != null) {
            "The user attached a file named '$fileName'.\n\n--- FILE CONTENT ---\n$fileText\n--- END FILE ---\n\nUser request: $text"
        } else text
        clearAttachment()
        runGeneration(conv, modelText, display)
    }

    private fun handleNoonRequest(text: String) {
        prompt.setText("")
        addUserMessage(text)
        addAssistantMessage("I can hand this request to Noon. I’ll open Noon with your request as the search. Login and payment remain inside Noon, and the final order stays under your control.")
        addActionButton("Search in Noon") {
            AlertDialog.Builder(this)
                .setTitle("Open Noon")
                .setMessage("Search Noon for:\n\n$text\n\nAI Talk will not read or store your Noon password or payment-card details.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Continue") { _, _ -> openNoon(text) }
                .show()
        }
    }

    private fun sendGmailDraft(text: String) {
        val conv = conversation ?: run {
            Toast.makeText(this, "Load AI first", Toast.LENGTH_SHORT).show()
            return
        }
        val recipient = findEmailAddress(text)
        val modelPrompt =
            "Draft the email requested below. Return exactly this format and nothing else:\n" +
                "SUBJECT: <short subject>\nBODY: <email body>\n\nRequest: $text"
        runGeneration(conv, modelPrompt, text) { answer ->
            val draft = parseEmailDraft(answer)
            addActionButton("Open draft in Gmail") {
                openGmail(recipient, draft.first, draft.second)
            }
        }
    }

    private fun runGeneration(
        conv: Conversation,
        modelText: String,
        displayText: String,
        onComplete: ((String) -> Unit)? = null
    ) {
        prompt.setText("")
        addUserMessage(displayText)
        activeAssistantBubble = addBubble("", false)
        generating = true
        sendButton.isEnabled = false
        prompt.isEnabled = false
        status.text = "Thinking locally…"
        status.setTextColor(Color.rgb(80, 110, 180))

        val answer = StringBuilder()
        try {
            conv.sendMessageAsync(
                modelText,
                object : MessageCallback {
                    override fun onMessage(message: Message) {
                        val chunk = message.toString()
                        if (chunk.isNotEmpty()) {
                            answer.append(chunk)
                            runOnUiThread {
                                activeAssistantBubble?.text = cleanMarkdown(answer.toString())
                                scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
                            }
                        }
                    }

                    override fun onDone() {
                        val finalText = cleanMarkdown(answer.toString()).trim()
                        runOnUiThread {
                            generating = false
                            sendButton.isEnabled = true
                            prompt.isEnabled = true
                            status.text = "AI ready • $loadedBackend • fully offline"
                            status.setTextColor(GREEN_DARK)
                            prompt.requestFocus()
                            showKeyboard()
                            onComplete?.invoke(finalText)
                        }
                    }

                    override fun onError(throwable: Throwable) {
                        runOnUiThread {
                            generating = false
                            sendButton.isEnabled = true
                            prompt.isEnabled = true
                            activeAssistantBubble?.text = "Error: ${throwable.message ?: throwable.javaClass.simpleName}"
                            status.text = "Generation error"
                            status.setTextColor(EAND_RED)
                        }
                    }
                },
                maxOutputToken = 1000,
                thinkingConfig = ThinkingConfig(enableThinking = false)
            )
        } catch (t: Throwable) {
            generating = false
            sendButton.isEnabled = true
            prompt.isEnabled = true
            activeAssistantBubble?.text = "Error: ${t.message ?: t.javaClass.simpleName}"
        }
    }

    private fun openNoon(query: String) {
        try {
            val url = "https://www.noon.com/uae-en/search?q=${Uri.encode(query)}"
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (t: Throwable) {
            Toast.makeText(this, "Could not open Noon: ${t.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun openGmail(recipient: String?, subject: String, body: String) {
        val uri = Uri.parse("mailto:${recipient ?: ""}")
        val base = Intent(Intent.ACTION_SENDTO, uri).apply {
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, body)
        }
        try {
            startActivity(Intent(base).apply { setPackage("com.google.android.gm") })
        } catch (_: ActivityNotFoundException) {
            try {
                startActivity(base)
            } catch (t: Throwable) {
                Toast.makeText(this, "Could not open Gmail: ${t.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun findEmailAddress(text: String): String? {
        val matcher = EMAIL_PATTERN.matcher(text)
        return if (matcher.find()) matcher.group() else null
    }

    private fun parseEmailDraft(text: String): Pair<String, String> {
        val subjectMatch = Regex("(?im)^SUBJECT:\\s*(.+)$").find(text)
        val bodyMatch = Regex("(?is)BODY:\\s*(.*)$").find(text)
        val subject = subjectMatch?.groupValues?.getOrNull(1)?.trim().orEmpty().ifBlank { "AI Talk draft" }
        val body = bodyMatch?.groupValues?.getOrNull(1)?.trim().orEmpty().ifBlank {
            text.replace(Regex("(?im)^SUBJECT:.*$"), "").replace(Regex("(?im)^BODY:\\s*"), "").trim()
        }
        return subject to body
    }

    private fun cleanMarkdown(text: String): String {
        return text
            .replace("**", "")
            .replace(Regex("(?m)^#{1,6}\\s*"), "")
    }

    private fun addUserMessage(text: String) {
        addBubble(text, true)
    }

    private fun addAssistantMessage(text: String) {
        addBubble(text, false)
    }

    private fun addSystemMessage(text: String) {
        val tv = TextView(this).apply {
            this.text = text
            textSize = 11.8f
            setTextColor(MUTED)
            setPadding(dp(6), dp(7), dp(6), dp(7))
        }
        messages.addView(tv, LinearLayout.LayoutParams(-1, -2))
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun addBubble(text: String, fromUser: Boolean): TextView {
        val wrapper = LinearLayout(this).apply {
            gravity = if (fromUser) Gravity.END else Gravity.START
            setPadding(0, dp(5), 0, dp(5))
        }
        val tv = TextView(this).apply {
            this.text = text
            textSize = 15.2f
            setTextColor(if (fromUser) Color.WHITE else BLACK)
            setPadding(dp(14), dp(11), dp(14), dp(11))
            background = if (fromUser) roundedBg(EAND_RED, dp(17).toFloat())
            else roundedStrokeBg(Color.rgb(246, 247, 249), Color.rgb(232, 234, 238), dp(17).toFloat())
            maxWidth = (resources.displayMetrics.widthPixels * 0.84).toInt()
            setLineSpacing(dp(1).toFloat(), 1.03f)
        }
        wrapper.addView(tv)
        messages.addView(wrapper, LinearLayout.LayoutParams(-1, -2))
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        return tv
    }

    private fun addActionButton(label: String, action: () -> Unit) {
        val wrapper = LinearLayout(this).apply {
            gravity = Gravity.START
            setPadding(0, 0, 0, dp(7))
        }
        val button = smallButton(label, outlined = true).apply {
            setTextColor(EAND_RED)
            setOnClickListener { action() }
        }
        wrapper.addView(button, LinearLayout.LayoutParams(-2, dp(42)))
        messages.addView(wrapper)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun refreshModelState() {
        if (localModel.exists()) {
            status.text = "Local model found • ${formatBytes(localModel.length())} • tap Load AI"
            status.setTextColor(GREEN_DARK)
            loadButton.isEnabled = true
        } else {
            status.text = "Import Qwen3 1.7B .litertlm once, then it stays on this phone"
            status.setTextColor(MUTED)
            loadButton.isEnabled = false
        }
    }

    private fun querySize(uri: Uri): Long {
        return try {
            contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getLong(0) else -1L
            } ?: -1L
        } catch (_: Throwable) {
            -1L
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "local"
        val mb = bytes / (1024.0 * 1024.0)
        return if (mb >= 1024) String.format(Locale.US, "%.2f GB", mb / 1024.0)
        else String.format(Locale.US, "%.0f MB", mb)
    }

    private fun showKeyboard() {
        prompt.postDelayed({
            (getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)
                ?.showSoftInput(prompt, InputMethodManager.SHOW_IMPLICIT)
        }, 120)
    }

    private fun smallButton(label: String, outlined: Boolean): Button {
        return Button(this).apply {
            text = label
            textSize = 12.8f
            isAllCaps = false
            minWidth = 0
            minimumWidth = 0
            setPadding(dp(14), 0, dp(14), 0)
            setTextColor(if (outlined) BLACK else Color.WHITE)
            background = if (outlined) roundedStrokeBg(Color.WHITE, BORDER, dp(12).toFloat())
            else roundedBg(EAND_RED, dp(12).toFloat())
        }
    }

    private fun roundedBg(color: Int, radius: Float): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(color)
            cornerRadius = radius
        }
    }

    private fun roundedStrokeBg(color: Int, stroke: Int, radius: Float): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(color)
            setStroke(dp(1), stroke)
            cornerRadius = radius
        }
    }

    private fun transparentBg(): GradientDrawable = roundedBg(Color.TRANSPARENT, 0f)

    private fun closeModel() {
        try { conversation?.close() } catch (_: Throwable) {}
        conversation = null
        try { engine?.close() } catch (_: Throwable) {}
        engine = null
    }

    override fun onDestroy() {
        closeModel()
        ioExecutor.shutdownNow()
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    companion object {
        private const val REQUEST_MODEL = 9001
        private const val REQUEST_ATTACHMENT = 9002
        private const val FILE_CONTEXT_LIMIT = 11_000

        private val EAND_RED = Color.rgb(220, 0, 28)
        private val BLACK = Color.rgb(27, 28, 31)
        private val MUTED = Color.rgb(105, 108, 115)
        private val BORDER = Color.rgb(224, 226, 230)
        private val GREEN_LIGHT = Color.rgb(232, 249, 239)
        private val GREEN_DARK = Color.rgb(26, 128, 72)
        private val AMBER = Color.rgb(177, 111, 0)
        private val EMAIL_PATTERN: Pattern = Pattern.compile("[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}", Pattern.CASE_INSENSITIVE)
    }
}
