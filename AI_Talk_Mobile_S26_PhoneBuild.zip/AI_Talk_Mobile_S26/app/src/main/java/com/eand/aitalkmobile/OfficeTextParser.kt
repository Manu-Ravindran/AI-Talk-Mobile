package com.eand.aitalkmobile

import org.w3c.dom.Element
import org.w3c.dom.Node
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.math.floor
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory

/**
 * Dependency-light OOXML text extraction for modern Word (.docx) and Excel (.xlsx) files.
 * This intentionally reads document text/data only; macros and embedded executable content are ignored.
 */
object OfficeTextParser {

    fun extractDocx(input: InputStream, maxChars: Int = 60_000): String {
        val entries = readRelevantZipEntries(input) { name ->
            name == "word/document.xml" ||
                name.startsWith("word/header") && name.endsWith(".xml") ||
                name.startsWith("word/footer") && name.endsWith(".xml")
        }
        val ordered = buildList {
            entries["word/document.xml"]?.let { add(it) }
            entries.filterKeys { it.startsWith("word/header") }.toSortedMap().values.forEach(::add)
            entries.filterKeys { it.startsWith("word/footer") }.toSortedMap().values.forEach(::add)
        }
        require(ordered.isNotEmpty()) { "Word document content was not found" }

        val out = StringBuilder()
        for (bytes in ordered) {
            val doc = parseXml(bytes)
            val paragraphs = doc.getElementsByTagNameNS("*", "p")
            for (i in 0 until paragraphs.length) {
                val p = paragraphs.item(i) as? Element ?: continue
                val line = collectWordParagraphText(p).trimEnd()
                if (line.isNotBlank()) appendLimited(out, line + "\n", maxChars)
                if (out.length >= maxChars) break
            }
            if (out.length >= maxChars) break
        }
        return out.toString().trim()
    }

    fun extractXlsx(input: InputStream, maxChars: Int = 60_000): String {
        val entries = readRelevantZipEntries(input) { name ->
            name == "xl/sharedStrings.xml" ||
                name == "xl/workbook.xml" ||
                name == "xl/_rels/workbook.xml.rels" ||
                name == "xl/styles.xml" ||
                name.startsWith("xl/worksheets/") && name.endsWith(".xml")
        }
        val worksheetEntries = entries.filterKeys { it.startsWith("xl/worksheets/") && it.endsWith(".xml") }
        require(worksheetEntries.isNotEmpty()) { "Excel worksheet content was not found" }

        val sharedStrings = parseSharedStrings(entries["xl/sharedStrings.xml"])
        val styles = parseExcelStyles(entries["xl/styles.xml"])
        val orderedSheets = resolveSheets(entries, worksheetEntries)
        val out = StringBuilder()

        for ((sheetName, bytes) in orderedSheets) {
            appendLimited(out, "=== SHEET: $sheetName ===\n", maxChars)
            val doc = parseXml(bytes)
            val rows = doc.getElementsByTagNameNS("*", "row")
            for (r in 0 until rows.length) {
                val row = rows.item(r) as? Element ?: continue
                val cells = row.getElementsByTagNameNS("*", "c")
                val values = ArrayList<String>(cells.length)
                for (c in 0 until cells.length) {
                    val cell = cells.item(c) as? Element ?: continue
                    val ref = cell.getAttribute("r")
                    val value = parseCellValue(cell, sharedStrings, styles)
                    if (value.isNotBlank()) values.add(if (ref.isNotBlank()) "$ref=$value" else value)
                }
                if (values.isNotEmpty()) appendLimited(out, values.joinToString("\t") + "\n", maxChars)
                if (out.length >= maxChars) break
            }
            appendLimited(out, "\n", maxChars)
            if (out.length >= maxChars) break
        }
        return out.toString().trim()
    }

    private fun parseSharedStrings(bytes: ByteArray?): List<String> {
        if (bytes == null) return emptyList()
        val doc = parseXml(bytes)
        val sis = doc.getElementsByTagNameNS("*", "si")
        val result = ArrayList<String>(sis.length)
        for (i in 0 until sis.length) {
            val si = sis.item(i) as? Element ?: continue
            val texts = si.getElementsByTagNameNS("*", "t")
            val value = buildString {
                for (j in 0 until texts.length) append(texts.item(j).textContent ?: "")
            }
            result.add(value)
        }
        return result
    }

    private fun resolveSheets(
        entries: Map<String, ByteArray>,
        worksheetEntries: Map<String, ByteArray>
    ): List<Pair<String, ByteArray>> {
        val workbookBytes = entries["xl/workbook.xml"]
        val relBytes = entries["xl/_rels/workbook.xml.rels"]
        if (workbookBytes == null || relBytes == null) {
            return worksheetEntries.toSortedMap().entries.mapIndexed { index, e ->
                "Sheet ${index + 1}" to e.value
            }
        }

        val relMap = HashMap<String, String>()
        val relDoc = parseXml(relBytes)
        val rels = relDoc.getElementsByTagNameNS("*", "Relationship")
        for (i in 0 until rels.length) {
            val rel = rels.item(i) as? Element ?: continue
            val id = rel.getAttribute("Id")
            val target = rel.getAttribute("Target")
            if (id.isNotBlank() && target.isNotBlank()) relMap[id] = normalizeWorksheetPath(target)
        }

        val result = ArrayList<Pair<String, ByteArray>>()
        val workbookDoc = parseXml(workbookBytes)
        val sheets = workbookDoc.getElementsByTagNameNS("*", "sheet")
        for (i in 0 until sheets.length) {
            val sheet = sheets.item(i) as? Element ?: continue
            val name = sheet.getAttribute("name").ifBlank { "Sheet ${i + 1}" }
            var relId = sheet.getAttributeNS(
                "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
                "id"
            )
            if (relId.isBlank()) relId = sheet.getAttribute("r:id")
            val path = relMap[relId] ?: continue
            val bytes = worksheetEntries[path] ?: continue
            result.add(name to bytes)
        }

        if (result.isEmpty()) {
            return worksheetEntries.toSortedMap().entries.mapIndexed { index, e ->
                "Sheet ${index + 1}" to e.value
            }
        }
        return result
    }

    private data class ExcelStyles(
        val dateStyles: Set<Int>,
        val timeStyles: Set<Int>,
        val dateTimeStyles: Set<Int>
    )

    private fun parseExcelStyles(bytes: ByteArray?): ExcelStyles {
        if (bytes == null) return ExcelStyles(emptySet(), emptySet(), emptySet())
        val doc = parseXml(bytes)
        val customFormats = HashMap<Int, String>()
        val numFmts = doc.getElementsByTagNameNS("*", "numFmt")
        for (i in 0 until numFmts.length) {
            val n = numFmts.item(i) as? Element ?: continue
            val id = n.getAttribute("numFmtId").toIntOrNull() ?: continue
            customFormats[id] = n.getAttribute("formatCode")
        }

        val date = HashSet<Int>()
        val time = HashSet<Int>()
        val dateTime = HashSet<Int>()
        val cellXfs = doc.getElementsByTagNameNS("*", "cellXfs")
        if (cellXfs.length == 0) return ExcelStyles(date, time, dateTime)
        val xfs = (cellXfs.item(0) as Element).getElementsByTagNameNS("*", "xf")
        for (styleIndex in 0 until xfs.length) {
            val xf = xfs.item(styleIndex) as? Element ?: continue
            val numFmtId = xf.getAttribute("numFmtId").toIntOrNull() ?: 0
            val kind = excelDateFormatKind(numFmtId, customFormats[numFmtId])
            when (kind) {
                1 -> date.add(styleIndex)
                2 -> time.add(styleIndex)
                3 -> dateTime.add(styleIndex)
            }
        }
        return ExcelStyles(date, time, dateTime)
    }

    /** 0=normal, 1=date, 2=time, 3=date+time */
    private fun excelDateFormatKind(numFmtId: Int, custom: String?): Int {
        val builtInDate = numFmtId in 14..17 || numFmtId in 27..36 || numFmtId in 50..58
        val builtInTime = numFmtId in 18..21 || numFmtId in 45..47
        if (numFmtId == 22) return 3
        if (builtInDate) return 1
        if (builtInTime) return 2
        if (custom.isNullOrBlank()) return 0
        val cleaned = custom.lowercase()
            .replace(Regex("\\\\."), "")
            .replace(Regex("\"[^\"]*\""), "")
            .replace(Regex("\\[[^]]*]"), "")
        val hasDate = cleaned.contains('y') || cleaned.contains('d')
        val hasTime = cleaned.contains('h') || cleaned.contains('s')
        return when {
            hasDate && hasTime -> 3
            hasDate -> 1
            hasTime -> 2
            else -> 0
        }
    }

    private fun parseCellValue(cell: Element, sharedStrings: List<String>, styles: ExcelStyles): String {
        val type = cell.getAttribute("t")
        if (type == "inlineStr") {
            val ts = cell.getElementsByTagNameNS("*", "t")
            return buildString {
                for (i in 0 until ts.length) append(ts.item(i).textContent ?: "")
            }
        }

        val vNodes = cell.getElementsByTagNameNS("*", "v")
        val raw = if (vNodes.length > 0) vNodes.item(0).textContent.orEmpty() else ""
        if (type.isBlank() || type == "n") {
            val styleIndex = cell.getAttribute("s").toIntOrNull()
            val numeric = raw.toDoubleOrNull()
            if (styleIndex != null && numeric != null) {
                val kind = when {
                    styleIndex in styles.dateTimeStyles -> 3
                    styleIndex in styles.dateStyles -> 1
                    styleIndex in styles.timeStyles -> 2
                    else -> 0
                }
                if (kind != 0) return formatExcelSerial(numeric, kind)
            }
        }
        return when (type) {
            "s" -> raw.toIntOrNull()?.let { sharedStrings.getOrNull(it) } ?: raw
            "b" -> if (raw == "1") "TRUE" else if (raw == "0") "FALSE" else raw
            "str" -> raw
            else -> raw
        }
    }

    private fun formatExcelSerial(serial: Double, kind: Int): String {
        return try {
            val wholeDays = floor(serial).toLong()
            val fraction = serial - wholeDays
            val seconds = (fraction * 86_400.0).toLong().coerceIn(0, 86_399)
            val dt = LocalDateTime.of(1899, 12, 30, 0, 0).plusDays(wholeDays).plusSeconds(seconds)
            when (kind) {
                1 -> dt.toLocalDate().toString()
                2 -> dt.toLocalTime().withNano(0).toString()
                else -> dt.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
            }
        } catch (_: Throwable) {
            serial.toString()
        }
    }

    private fun collectWordParagraphText(element: Element): String {
        val out = StringBuilder()
        fun walk(node: Node) {
            when (node.nodeType) {
                Node.ELEMENT_NODE -> {
                    val local = node.localName ?: node.nodeName.substringAfter(':')
                    when (local) {
                        "t" -> out.append(node.textContent ?: "")
                        "tab" -> out.append('\t')
                        "br", "cr" -> out.append('\n')
                        else -> {
                            val children = node.childNodes
                            for (i in 0 until children.length) walk(children.item(i))
                        }
                    }
                }
                Node.TEXT_NODE -> Unit
            }
        }
        walk(element)
        return out.toString()
    }

    private fun normalizeWorksheetPath(target: String): String {
        val cleaned = target.replace('\\', '/').removePrefix("/")
        return when {
            cleaned.startsWith("xl/") -> cleaned
            cleaned.startsWith("../") -> "xl/" + cleaned.removePrefix("../")
            else -> "xl/$cleaned"
        }.replace("xl/worksheets/../", "xl/")
    }

    private fun parseXml(bytes: ByteArray) = DocumentBuilderFactory.newInstance().apply {
        isNamespaceAware = true
        try { setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) } catch (_: Throwable) {}
        try { setFeature("http://xml.org/sax/features/external-general-entities", false) } catch (_: Throwable) {}
        try { setFeature("http://xml.org/sax/features/external-parameter-entities", false) } catch (_: Throwable) {}
    }.newDocumentBuilder().parse(ByteArrayInputStream(bytes))

    private fun readRelevantZipEntries(
        input: InputStream,
        accept: (String) -> Boolean
    ): Map<String, ByteArray> {
        val result = LinkedHashMap<String, ByteArray>()
        ZipInputStream(input.buffered()).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                val name = entry.name.replace('\\', '/')
                if (!entry.isDirectory && accept(name)) {
                    val bytes = zip.readBytesLimited(MAX_XML_ENTRY_BYTES)
                    result[name] = bytes
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }
        return result
    }

    private fun InputStream.readBytesLimited(max: Int): ByteArray {
        val buffer = ByteArray(8192)
        val out = java.io.ByteArrayOutputStream()
        var total = 0
        while (true) {
            val n = read(buffer)
            if (n <= 0) break
            total += n
            require(total <= max) { "Office XML section is too large" }
            out.write(buffer, 0, n)
        }
        return out.toByteArray()
    }

    private fun appendLimited(out: StringBuilder, text: String, maxChars: Int) {
        if (out.length >= maxChars) return
        val remaining = maxChars - out.length
        if (text.length <= remaining) out.append(text) else out.append(text, 0, remaining)
    }

    private const val MAX_XML_ENTRY_BYTES = 12 * 1024 * 1024
}
