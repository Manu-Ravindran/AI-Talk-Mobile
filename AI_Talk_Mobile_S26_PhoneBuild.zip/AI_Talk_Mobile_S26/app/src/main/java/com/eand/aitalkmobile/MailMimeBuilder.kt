package com.eand.aitalkmobile

import java.nio.charset.StandardCharsets
import java.util.Base64
import java.util.UUID

object MailMimeBuilder {
    fun build(
        to: String,
        subject: String,
        body: String,
        attachmentName: String? = null,
        attachmentContentType: String? = null,
        attachmentBytes: ByteArray? = null,
        inReplyTo: String? = null,
        references: String? = null
    ): String {
        val safeSubject = encodeHeader(subject)
        val common = buildString {
            append("To: ").append(to).append("\r\n")
            append("Subject: ").append(safeSubject).append("\r\n")
            append("MIME-Version: 1.0\r\n")
            if (!inReplyTo.isNullOrBlank()) append("In-Reply-To: ").append(inReplyTo).append("\r\n")
            if (!references.isNullOrBlank()) append("References: ").append(references).append("\r\n")
        }

        if (attachmentBytes == null || attachmentName.isNullOrBlank()) {
            return buildString {
                append(common)
                append("Content-Type: text/plain; charset=UTF-8\r\n")
                append("Content-Transfer-Encoding: base64\r\n\r\n")
                append(base64Mime(body.toByteArray(StandardCharsets.UTF_8)))
                append("\r\n")
            }
        }

        val boundary = "aitalk_${UUID.randomUUID()}"
        return buildString {
            append(common)
            append("Content-Type: multipart/mixed; boundary=\"").append(boundary).append("\"\r\n\r\n")
            append("--").append(boundary).append("\r\n")
            append("Content-Type: text/plain; charset=UTF-8\r\n")
            append("Content-Transfer-Encoding: base64\r\n\r\n")
            append(base64Mime(body.toByteArray(StandardCharsets.UTF_8))).append("\r\n")
            append("--").append(boundary).append("\r\n")
            append("Content-Type: ").append(attachmentContentType.orEmpty().ifBlank { "application/octet-stream" })
                .append("; name=\"").append(escapeQuoted(attachmentName)).append("\"\r\n")
            append("Content-Disposition: attachment; filename=\"").append(escapeQuoted(attachmentName)).append("\"\r\n")
            append("Content-Transfer-Encoding: base64\r\n\r\n")
            append(base64Mime(attachmentBytes)).append("\r\n")
            append("--").append(boundary).append("--\r\n")
        }
    }

    fun toBase64Url(rawMessage: String): String =
        Base64.getUrlEncoder().withoutPadding().encodeToString(rawMessage.toByteArray(StandardCharsets.UTF_8))

    private fun encodeHeader(value: String): String {
        val cleaned = value.replace("\r", " ").replace("\n", " ")
        if (cleaned.all { it.code in 32..126 }) return cleaned
        return "=?UTF-8?B?${Base64.getEncoder().encodeToString(cleaned.toByteArray(StandardCharsets.UTF_8))}?="
    }

    private fun escapeQuoted(value: String): String = value.replace("\\", "_").replace("\"", "'")

    private fun base64Mime(bytes: ByteArray): String =
        Base64.getMimeEncoder(76, "\r\n".toByteArray(StandardCharsets.US_ASCII)).encodeToString(bytes)
}
