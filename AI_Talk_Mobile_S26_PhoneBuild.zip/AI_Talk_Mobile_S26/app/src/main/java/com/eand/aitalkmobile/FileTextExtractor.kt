package com.eand.aitalkmobile

import android.content.Context
import android.net.Uri
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale

object FileTextExtractor {

    fun extract(context: Context, uri: Uri, fileName: String): String {
        val lower = fileName.lowercase(Locale.US)
        val result = when {
            lower.endsWith(".pdf") -> extractPdf(context, uri)
            lower.endsWith(".xlsx") -> context.contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "Cannot open Excel file" }
                OfficeTextParser.extractXlsx(input, MAX_EXTRACT_CHARS)
            }
            lower.endsWith(".docx") -> context.contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "Cannot open Word file" }
                OfficeTextParser.extractDocx(input, MAX_EXTRACT_CHARS)
            }
            lower.endsWith(".txt") || lower.endsWith(".csv") || lower.endsWith(".json") ||
                lower.endsWith(".md") || lower.endsWith(".log") -> extractText(context, uri)
            lower.endsWith(".xls") || lower.endsWith(".doc") ->
                throw IllegalArgumentException("Legacy .xls/.doc is not supported in this phone build. Save as .xlsx/.docx and attach again.")
            else -> throw IllegalArgumentException("Supported files: PDF, XLSX, DOCX, TXT, CSV, JSON and Markdown")
        }
        return result.trim().ifBlank { "[The selected file contained no extractable text.]" }
    }

    private fun extractText(context: Context, uri: Uri): String {
        val builder = StringBuilder()
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Cannot open file" }
            BufferedReader(InputStreamReader(input, Charsets.UTF_8)).useLines { lines ->
                for (line in lines) {
                    builder.append(line).append('\n')
                    if (builder.length >= MAX_EXTRACT_CHARS) return@useLines
                }
            }
        }
        return builder.toString()
    }

    private fun extractPdf(context: Context, uri: Uri): String {
        PDFBoxResourceLoader.init(context.applicationContext)
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Cannot open PDF" }
            PDDocument.load(input).use { doc ->
                val stripper = PDFTextStripper().apply {
                    sortByPosition = true
                    endPage = minOf(doc.numberOfPages, 50)
                }
                val text = stripper.getText(doc)
                return if (text.length > MAX_EXTRACT_CHARS) text.take(MAX_EXTRACT_CHARS) else text
            }
        }
    }

    private const val MAX_EXTRACT_CHARS = 60_000
}
