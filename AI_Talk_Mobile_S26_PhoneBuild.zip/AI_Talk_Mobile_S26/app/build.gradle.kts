plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.eand.aitalkmobile"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.eand.aitalkmobile"
        minSdk = 31
        targetSdk = 36
        versionCode = 2
        versionName = "0.2.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }

    packaging {
        jniLibs {
            useLegacyPackaging = false
        }
        resources {
            excludes += setOf(
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE*",
                "META-INF/NOTICE*",
                "META-INF/AL2.0",
                "META-INF/LGPL2.1"
            )
        }
    }

    signingConfigs {
        create("aitalkDev") {
            storeFile = file("ai-talk-debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("aitalkDev")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("aitalkDev")
        }
    }
}

kotlin {
    jvmToolchain(21)
}

dependencies {
    implementation("com.google.ai.edge.litertlm:litertlm-android:latest.release")
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
}
